#include "traverse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char piece_is_sud(Case piece) {
  switch (piece) {
  case Carre_Sud:
  case Rond_Sud:
  case Triangle_Sud:
  case Losange_Sud:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_nord(Case piece) {
  switch (piece) {
  case Carre_Nord:
  case Rond_Nord:
  case Triangle_Nord:
  case Losange_Nord:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_est(Case piece) {
  switch (piece) {
  case Carre_Est:
  case Rond_Est:
  case Triangle_Est:
  case Losange_Est:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_ouest(Case piece) {
  switch (piece) {
  case Carre_Ouest:
  case Rond_Ouest:
  case Triangle_Ouest:
  case Losange_Ouest:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_rond(Case piece) {
  switch (piece) {
  case Rond_Nord:
  case Rond_Sud:
  case Rond_Ouest:
  case Rond_Est:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_carre(Case piece) {
  switch (piece) {
  case Carre_Nord:
  case Carre_Sud:
  case Carre_Ouest:
  case Carre_Est:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_losange(Case piece) {
  switch (piece) {
  case Losange_Nord:
  case Losange_Sud:
  case Losange_Ouest:
  case Losange_Est:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_triangle_nord(Case piece) {
  switch (piece) {
  case Triangle_Nord:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_triangle_sud(Case piece) {
  switch (piece) {
  case Triangle_Sud:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}
char piece_is_triangle_est(Case piece) {
  switch (piece) {
  case Triangle_Est:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char piece_is_triangle_ouest(Case piece) {
  switch (piece) {
  case Triangle_Ouest:
    return 1;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

int nombre_de_joueur() {
  int n;
  n = 0;
  printf("Le jeu peut se jouer a 2 ou 4 joueurs.\n Pour jouer a 2 entrez 2.\n "
         "Pour jouez a 4 entrez 4.\n");
  scanf("%d", &n);
  int c;
  while ((c = getchar()) != '\n' && c != EOF)
    ; // pour lire le retour chariot du scanf

  while ((n != 2) && (n != 4)) {
    printf("Erreur le nombre entre ne correspond a aucun mode de jeu.\n");
    printf("%d\n", n);
    printf("Le jeu peut se jouer a 2 ou 4 joueurs.\n Pour jouer a 2 entrez "
           "2.\n Pour jouez a 4 entrez 4.\n");
    scanf("%d", &n);
    printf("\n");
  }
  return n;
}

int oui_ou_non() {
  char buf[1024];
  scanf("%1024s", buf);
  int c;
  while ((c = getchar()) != '\n' && c != EOF)
    ; // pour lire le retour chariot du scanf
  if (strcmp(buf, "O")==0)
    return 1;
  return 0;
}

Joueur joueur_qui_joue(Joueur joueur, Tour *tour, int nb_joueur) {
  if (nb_joueur == 2) {
    if (joueur == Sud)
      return Nord;
    else {
      ++(tour->n);
      return Sud;
    }
  } else if (nb_joueur == 4) {
    if (joueur == Sud) {
      return Est;
    } else if (joueur == Est) {
      return Nord;
    } else if (joueur == Nord) {
      return Ouest;
    } else {
      ++(tour->n);
      return Sud;
    }
  }
  return 0;
}

void print_joueur(Joueur joueur) {
  if (joueur == Sud) {
    printf("Sud");
  } else if (joueur == Nord) {
    printf("Nord");
  } else if (joueur == Est) {
    printf("Est");
  } else {
    printf("Ouest");
  }
}
