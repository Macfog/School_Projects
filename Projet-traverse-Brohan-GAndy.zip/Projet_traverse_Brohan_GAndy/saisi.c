#include <stdlib.h>
#include "traverse.h"
#include <stdio.h>
#include <string.h>

char get_coord(char *buf, int *x)
{
        if (*buf >= '0' && *buf <= '9')
        {
                *x = (*buf) - '0';
                return 1;
        }
        else
                return 0;
}

char test_saisie(char *buf)
{
        int npos = 0;
        int sz = strlen(buf);
        if (sz < 5)
        {               
                return 0;
        }
        int x, y;
        if (get_coord(buf, &x))
                ++buf;
        else
                return 0;
        if (get_coord(buf, &y))
                ++buf;
        else
                return 0;
        ++npos;
 //       printf("depart x y %i %i\n", x, y);

        for (; *buf != 0;)
        {
                if (*buf < 32)
                {
                        ++buf;
                        continue;
                }

                if (*buf >= ' ')
                        ++buf;
                else
                        return 0;
                if (get_coord(buf, &x))
                        ++buf;
                else
                        return 0;
                if (get_coord(buf, &y))
                        ++buf;
                else
                        return 0;
   //             printf("pos x y %i %i\n", x, y);
                ++npos;
        }

        return npos;
}

char saisie(char *buf_tmp)
{
        fgets(buf_tmp, 1024, stdin);
        return test_saisie(buf_tmp);
}

void coup(Plateau *p, Coord a, Coord b)
{
        p->cases[b.y][b.x] = p->cases[a.y][a.x];
        p->cases[a.y][a.x] = vide;
}

int joue(char *buf, int npos, Partie *partie) {
  Coord a, b;
  a.x = buf[0] - '0';
  a.y = buf[1] - '0';
  b.x = buf[(npos - 1) * 3] - '0';
  b.y = buf[(npos - 1) * 3 + 1] - '0';
  if (!bordure(b, partie->joueur)) {
    printf("Mauvais coup la piece termine dans une bordure recommencez!1\n");
  } else {
    if (sauvegarde_du_plateau(&partie->plateau, a, b, &partie->sauvegarde)) {
    }
    coup(&partie->plateau, a, b);

    if (partie_finie(partie)) {
      return 1;
    }
    partie->joueur = joueur_qui_joue(partie->joueur, &partie->tour, partie->nombre_j);
  }
  return 0;
}

char partie_finie(Partie * partie) {
    if (defaite(&partie->plateau, partie->tour, partie->joueur)) {
      printf("Defaite du joueur ");
      print_joueur(partie->joueur);
      printf(" tous les pions non pas ete sortis de leur zone de depart.\n");
      partie->etat_partie = Fin;
      return 1;
    }
    if (victoire(&partie->plateau, partie->joueur)) {
      printf("Victoire du joueur ");
      print_joueur(partie->joueur);
      printf(" fin de la partie\n");
      partie->etat_partie = Fin;
      return 1;
    }
    if (sauvegarde_plateau_existe_2_fois(&partie->sauvegarde, &partie->plateau)) {
        printf("Match nul 3 repetitions\n");
        partie->etat_partie = Fin;
        return 1;
      }

    return 0;
}
