#ifndef __TRAVERSE_GUI_H__
#define __TRAVERSE_GUI_H__

#include "traverse.h"


char init_gui();
void render_plateau(Plateau *p, CoupsPossibles *coups);
char run_gui();
void free_tous_messages();
char stop_gui();


#endif