#ifndef __TRAVERSE_H__
#define __TRAVERSE_H__

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
        int n; /* n° du Tour */
} Tour;

typedef struct
{
        int x;
        int y;
} Coord;

typedef enum
{
        vide,
        Rond_Sud,
        Rond_Nord,
        Rond_Ouest,
        Rond_Est,
        Triangle_Nord,
        Triangle_Est,
        Triangle_Sud,
        Triangle_Ouest,
        Losange_Nord,
        Losange_Est,
        Losange_Sud,
        Losange_Ouest,
        Carre_Nord,
        Carre_Est,
        Carre_Sud,
        Carre_Ouest
} Case;

typedef struct
{
        Case cases[10][10];
} Plateau;

typedef struct SauvegardePlateau
{
        Plateau plateau;
        struct SauvegardePlateau *suivant;
        Coord a; // position dans plateau
        Coord b; // position dans suivant->plateau

} SauvegardePlateau;

typedef struct
{
        SauvegardePlateau *premiere;
        SauvegardePlateau *derniere;

} Sauvegarde;

typedef enum
{
        Nord,
        Sud,
        Est,
        Ouest
} Joueur;

typedef struct {
        enum { Joue, Fin} etat_partie;
        int nombre_j;
        Plateau plateau;
        Tour tour;
        Joueur joueur;
        Sauvegarde sauvegarde;
        char ia[4];
} Partie;

int nombre_de_joueur();
int oui_ou_non();
void plateau_init(Plateau *p, int nombre_de_joueur);
void init_plateau_vide(Plateau *p);
void plateau_print(Plateau *p);
void plateau_copie_dans(Plateau *porigine, Plateau *pdestination);

Joueur joueur_qui_joue(Joueur joueur, Tour *tour, int nombre_de_joueur);

void print_joueur(Joueur joueur);

void coup(Plateau *p, Coord a, Coord b);

char piece_is_sud(Case piece);
char piece_is_nord(Case piece);
char piece_is_est(Case piece);
char piece_is_ouest(Case piece);
char piece_is_rond(Case piece);
char piece_is_carre(Case piece);
char piece_is_losange(Case piece);
char piece_is_triangle_nord(Case piece);
char piece_is_triangle_sud(Case piece);
char piece_is_triangle_est(Case piece);
char piece_is_triangle_ouest(Case piece);

int regle(Joueur joueur, Coord a, Coord b, Plateau *p);

#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))

char get_coord(char *buf, int *x);
char saisie(char *buf_tmp);
int detection_des_sauts(Joueur joueur, Coord a, Coord b, Plateau *p);
int detection_des_sauts_destination(Case piece, Coord a, Coord b, Plateau *p);

int regle_saut(Plateau *p, Coord a, Coord b);
int bordure(Coord b, Joueur joueur);
int est_arrivee(Coord b, Joueur joueur);

char coup_valide(Joueur joueur, Plateau *p, int n, char *buf_tmp, Coord *a, Coord *b);

//char sauvegarde_du_plateau(Plateau *p, Tour tour, Plateau *sauvegarde);
int match_null(Plateau *sauvegarde, Tour tour);
int defaite(Plateau *p, Tour tour, Joueur joueur);
int victoire(Plateau *p, Joueur joueur);



SauvegardePlateau *copie_plateau(Plateau *p);
char plateau_identiques(Plateau *p1, Plateau *p2);

void sauvegarde_init(Sauvegarde *sav);
void sauvegarde_ajoute(Sauvegarde *sav, SauvegardePlateau *savplateau);
char sauvegarde_plateau_existe_2_fois(Sauvegarde *sav, Plateau *plateau);
char sauvegarde_ecrit(Sauvegarde *sav, char *nfichier, int nombre_j);
char sauvegarde_lit(Sauvegarde *sav, Plateau *plateau, Joueur *joueur, char *nfichier, Tour *tour, int *nombre_de_joueur);

typedef struct
{
        Coord depart;
        Coord arrivee;
} Coup;

typedef struct
{
        Coup *tcoups;
        int ncoups;
        int max_sz;
} CoupsPossibles;

void coups_possibles_init(CoupsPossibles *coups_possibles);
void coups_possibles_add_coups(CoupsPossibles *coups_possibles, Coup);
void coups_possibles_free(CoupsPossibles *coups_possibles);
void coups_possibles_vide(CoupsPossibles *coups_possibles);

void coups_possibles_depl_depuis(Plateau *plateau, Joueur joueur, Coord depart, CoupsPossibles *coups_possibles);
void coups_possibles_sauts_depuis(Plateau *plateau, Joueur joueur, Coord depart, CoupsPossibles *coups_possibles);
void coups_possibles_depuis(Plateau *plateau, Joueur joueur, Coord depart, CoupsPossibles *coups_possibles);
void coups_possibles_joueur(Plateau *plateau, Joueur joueur, CoupsPossibles *coups_possibles);

char sauvegarde_chargement(Plateau *p, Joueur joueur, Sauvegarde *s, int nombre_de_joueur, char *buf_tmp, Tour tour);
char sauvegarde_du_plateau(Plateau *p, Coord a, Coord b, Sauvegarde *s);

char test_saisie(char *buf);

void partie_init(Partie * partie, int nj);
int joue(char *buf, int n, Partie *partie);
char partie_finie(Partie * partie);

char ia_joue(Partie *partie);
float eval_position(Plateau * plateau, Joueur joueur);


#endif
