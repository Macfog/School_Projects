Le jeu possède trois exécutables :
 traverse : exécutable du jeu sur le terminale
 taverse_gui : exécutable du jeu avec une interface graphique
 traverse_test : exécutable des tests de différentes fonctions du programme

Règles du jeu :
Le jeu peut se jouer à 2 ou à 4 joueurs le choix se fait en début de partie.
Il est possible de mettre des ia le choix est proposé en début de partie.

un pion ne peut avancer que d'une case a l'exleption d'un saut.
Les ronds peuvent se déplacer dans toutes les directions
les losanges ne peuvent se déplacer qu'en diagonale
les carré ne peuvent se déplacer que sur les cotés devant/derriere
les triangles ne peuvent se déplacer qu'en diagonale vers l'avant ou reculer.

Pour sauvegarder une partie en cours il faut :
 sur le terminale entrer s
 sur l'intface graphique appuyer sur la touche s
Pour charger un partie il faut appuyer sur l

Pour jouer :
Avec le terminal, il faut entrer le nombre de joueur
puis choisir s'il y a des ia ou non.
pour déplacer un pion il faut
entrer les coordonnées de la pièce de départ (xy)
puis les coordonnées d’arrivée de la pièce.
exemple pour aller de la case 1 0 a la case 1 1
il faut entrer : 10 11


Avec l'interface graphique, il faut choisir un mode de jeu
puis choisir si il y a une ia ou non
pour deplacer un pion il faux :
faire un clique gauche sur le pion à déplacer.
les déplacements possible sont affiché par les cases grises
onctionnement des sauts:
Lors d’un saut simple il faut sélectionner la case possédant le pion pouvant
 sauter avec un clic gauche puis confirmer le saut par un clic droit.
Dans le cas d’un saut multiple il faut sélectionner la pièce à déplacer
puis sur toutes les cases  dans lesquelles il se déplacera
jusqu’à son arrivée puis confirmer la série de sauts par un clic droit.

