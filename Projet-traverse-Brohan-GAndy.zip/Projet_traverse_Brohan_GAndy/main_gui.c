#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "traverse.h"
#include "traverse_gui.h"

int main(int argc, char * argv[])
{
	srand(time(NULL));
	init_gui();
	int nombre_de_joueur;
	nombre_de_joueur = 2;
	if(argc > 1) {
		nombre_de_joueur = atoi(argv[1]);
	}
	if(nombre_de_joueur > 4) nombre_de_joueur = 4;
	else if(nombre_de_joueur != 2) nombre_de_joueur = 2;
	

	while (run_gui(nombre_de_joueur)) /* condition victoire non remplies */
	{
	}
	stop_gui();
}
