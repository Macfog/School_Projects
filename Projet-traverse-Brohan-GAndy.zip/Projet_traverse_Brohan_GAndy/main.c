#include "traverse.h"
#include <stdio.h>
#include <stdlib.h>
void defini_ia(Partie *partie) {
  printf("IA Sud (O pour oui autre non)?");
  partie->ia[Sud] = oui_ou_non();
  printf("IA Nord?");
  partie->ia[Nord] = oui_ou_non();
  if (partie->nombre_j == 4) {
    printf("IA Est?");
    partie->ia[Est] = oui_ou_non();
    printf("IA Ouest?");
    partie->ia[Ouest] = oui_ou_non();
  } else {
    partie->ia[Est] = 0;
    partie->ia[Ouest] = 0;
  }
}
int main(void) {
  Partie partie;
  int nombre_j;
  nombre_j = nombre_de_joueur();
  partie_init(&partie, nombre_j);
  defini_ia(&partie);

  CoupsPossibles coups_possibles;
  coups_possibles_init(&coups_possibles);

  char buf_tmp[1024];
  char partie_finie = 0;
  while (!partie_finie) /* condition victoire non remplies */
  {
    plateau_print(&partie.plateau);
    if (partie.ia[partie.joueur] == 0) {
      print_joueur(partie.joueur);
      printf(" ");

      int n = saisie(buf_tmp);
      if (buf_tmp[0] == 's') {

        char cmd[256];
        char nfichier[256];
        int n = sscanf(buf_tmp, "%s %s", cmd, nfichier);

        if (n == 2) {
          sauvegarde_ecrit(&partie.sauvegarde, nfichier, partie.nombre_j);
        } else {
          sauvegarde_ecrit(&partie.sauvegarde, "p1.txt", partie.nombre_j);
        }
        continue;
      } else if (buf_tmp[0] == 'l') {
        char cmd[256];
        char nfichier[256];
        int n = sscanf(buf_tmp, "%s %s", cmd, nfichier);

        if (n == 2) {
          sauvegarde_lit(&partie.sauvegarde, &partie.plateau, &partie.joueur,
                         nfichier, &partie.tour, &partie.nombre_j);
        } else {
          sauvegarde_lit(&partie.sauvegarde, &partie.plateau, &partie.joueur,
                         "p1.txt", &partie.tour, &partie.nombre_j);
          defini_ia(&partie);
        }
        plateau_print(&partie.plateau);

        continue;
      }

      coups_possibles_vide(&coups_possibles);
      coups_possibles_joueur(&partie.plateau, partie.joueur, &coups_possibles);
      if (coups_possibles.ncoups == 0) {
        printf("Pass\n");
        buf_tmp[0] = '0';
        buf_tmp[1] = '0';
        buf_tmp[2] = ' ';
        buf_tmp[3] = '0';
        buf_tmp[4] = '0';
        buf_tmp[5] = 0;
        if (joue(buf_tmp, 2, &partie) == 1) {
          partie_finie = 1;
        } else {
          continue;
        }
      }
      coups_possibles_vide(&coups_possibles);

      Coord a, b;
      if (coup_valide(partie.joueur, &partie.plateau, n, buf_tmp, &a, &b)) {
        if (joue(buf_tmp, n, &partie) == 1) {
          partie_finie = 1;

        } else {
          continue;
        }
      }
    } else {
      print_joueur(partie.joueur);
      printf(" joue:\n");

      ia_joue(&partie);
      if (partie.etat_partie == Fin) {
        //    sauvegarde_ecrit(&partie.sauvegarde, "fin.txt",
        //    partie.nombre_j);
        partie_finie = 1;
      }
    }
  }

  char *message = NULL;
  if (victoire(&partie.plateau, partie.joueur)) {
    switch (partie.joueur) {
    case Sud:
      message = "Victoire Sud";
      break;
    case Nord:
      message = "Victoire Nord";
      break;
    case Est:
      message = "Victoire Est";
      break;
    case Ouest:
      message = "Victoire Ouest";
      break;
    default:
      return 1;
      break;
    }
  } else if (defaite(&partie.plateau, partie.tour, partie.joueur)) {
    switch (partie.joueur) {
    case Sud:
      message = "Defaite Sud";
      break;
    case Nord:
      message = "Defaite Nord";
      break;
    case Est:
      message = "Defaite Est";
      break;
    case Ouest:
      message = "Defaite Ouest";
      break;
    default:
      return 1;
      break;
    }
  } else if (sauvegarde_plateau_existe_2_fois(&partie.sauvegarde,
                                              &partie.plateau)) {
    message = "Nulle";
  }
  printf("Fin : %s\n", message);
  plateau_print(&partie.plateau);

  return 0;
}