#include "traverse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 1er fonction de sauvegarde appelee
void sauvegarde_init(Sauvegarde *sav) {
  sav->premiere = NULL;
  sav->derniere = NULL;
}

// 2ieme fonction de sauvegarde appelee
char sauvegarde_ecrit(Sauvegarde *sav, char *nfichier, int nombre_j) {
  FILE *f = fopen(nfichier, "w");
  if (f == NULL)
    return 0;
  if (nombre_j == 2) {
    fprintf(f, "J2\n");
    SauvegardePlateau *cur_sav = sav->premiere;
    while (cur_sav != NULL) {
      fprintf(f, "%c%c %c%c\n", cur_sav->a.x + '0', cur_sav->a.y + '0',
              cur_sav->b.x + '0', cur_sav->b.y + '0');
      cur_sav = cur_sav->suivant;
    }
    fclose(f);
    return 1;
  } else if (nombre_j == 4) {
    fprintf(f, "J4\n");
    SauvegardePlateau *cur_sav = sav->premiere;
    while (cur_sav != NULL) {
      fprintf(f, "%c%c %c%c\n", cur_sav->a.x + '0', cur_sav->a.y + '0',
              cur_sav->b.x + '0', cur_sav->b.y + '0');
      cur_sav = cur_sav->suivant;
    }
    fclose(f);
    return 1;
  }
  return 0;
}

// 4ieme fonction de sauvegarde appelee
SauvegardePlateau *copie_plateau(Plateau *p) {
  SauvegardePlateau *ret = malloc(sizeof(SauvegardePlateau));
  for (int i = 0; i < 10; ++i)
    for (int j = 0; j < 10; ++j)
      ret->plateau.cases[i][j] = p->cases[i][j];
  ret->suivant = NULL;
  return ret;
}

// 5ieme fonction de sauvegarde appelee
void sauvegarde_ajoute(Sauvegarde *sav, SauvegardePlateau *savplateau) {
  if (sav->derniere == NULL) {
    sav->premiere = savplateau;
    sav->derniere = savplateau;
  } else {
    sav->derniere->suivant = savplateau;
    sav->derniere = savplateau;
  }
}

void sauvegarde_free(Sauvegarde *sav) {
  SauvegardePlateau *cur_sav = sav->premiere;
  while (cur_sav != NULL) {
    SauvegardePlateau *sav_suivant = cur_sav->suivant;
    free(cur_sav);
    cur_sav = sav_suivant;
  }
  sauvegarde_init(sav);
}

// 3ieme fonction sauvegarde a etre appelee
char sauvegarde_lit(Sauvegarde *sav, Plateau *plateau, Joueur *joueur,
                    char *nfichier, Tour *tour, int *nombre_j) {
  FILE *f = fopen(nfichier, "r");
  if (f == NULL)
    return 0;
  sauvegarde_free(sav);
  char buf_tmp[1024];
  char smode[1024];
  *joueur = Sud; 
  fgets(buf_tmp, 1024, f);
  sscanf(buf_tmp, "%s", smode);
  printf("---%s---\n", smode);

  if (strcmp(smode, "J4") == 0) {
    *nombre_j = 4;
    plateau_init(plateau, *nombre_j);

  } else if (strcmp(smode, "J2") == 0) {
    *nombre_j = 2;
    plateau_init(plateau, *nombre_j);
  } else {
      printf("Erreur lecture\n");
      fclose(f);
      return 0;
  }
  while (fgets(buf_tmp, 1024, f) != NULL) {
    if (strlen(buf_tmp) != 6) {
      continue;
    }
    Coord a, b;
    a.x = buf_tmp[0] - '0';
    a.y = buf_tmp[1] - '0';
    b.x = buf_tmp[3] - '0';
    b.y = buf_tmp[4] - '0';
    SauvegardePlateau *sav_plateau = copie_plateau(plateau);
    sav_plateau->a = a;
    sav_plateau->b = b;
    sauvegarde_ajoute(sav, sav_plateau);
    coup(plateau, a, b);
    *joueur = joueur_qui_joue(*joueur, tour, *nombre_j);
  }
  fclose(f);
  return 1;
}

char plateau_identiques(Plateau *p1, Plateau *p2) {
  for (int i = 0; i < 10; ++i)
    for (int j = 0; j < 10; ++j)
      if (p1->cases[i][j] != p2->cases[i][j])
        return 0;
  return 1;
}

// 6ime fonction de sauvegarde appelee
char sauvegarde_plateau_existe_2_fois(Sauvegarde *sav, Plateau *plateau) {
  SauvegardePlateau *cur_sav = sav->premiere;
  int n_identique = 0;
  if (cur_sav == NULL)
    return 0;
  do {
    if (plateau_identiques(plateau, &cur_sav->plateau)) {
      ++n_identique;
      if (n_identique == 2)
        return 1;
    }
    cur_sav = cur_sav->suivant;
  } while (cur_sav != NULL);
  return 0;
}

char sauvegarde_chargement(Plateau *p, Joueur joueur, Sauvegarde *s,
                           int nombre_j, char *buf_tmp, Tour tour) {
  if (buf_tmp[0] == 's') {

    char cmd[256];
    char nfichier[256];
    int n = sscanf(buf_tmp, "%s %s", cmd, nfichier);

    if (n == 2) {
      sauvegarde_ecrit(s, nfichier, nombre_j);
    } else {
      sauvegarde_ecrit(s, "p1.txt", nombre_j);
    }
    return 1;
  } else if (buf_tmp[0] == 'l') {
    char cmd[256];
    char nfichier[256];
    int n = sscanf(buf_tmp, "%s %s", cmd, nfichier);

    if (n == 2) {
      sauvegarde_lit(s, p, &joueur, nfichier, &tour, &nombre_j);
    } else {
      sauvegarde_lit(s, p, &joueur, "p1.txt", &tour, &nombre_j);
    }
    plateau_print(p);

    return 1;
  }
  return 0;
}

char sauvegarde_du_plateau(Plateau *p, Coord a, Coord b, Sauvegarde *s) {
  SauvegardePlateau *sav_plateau = copie_plateau(p);
  sav_plateau->a = a;
  sav_plateau->b = b;
  sauvegarde_ajoute(s, sav_plateau);
  return 1;
}