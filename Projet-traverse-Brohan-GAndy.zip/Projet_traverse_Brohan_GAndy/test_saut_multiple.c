#include <stdlib.h>
#include "traverse.h"
#include <stdio.h>
#include <string.h>
#include "Test.h"

void test_sauts_mult_Rond(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Rond_Sud;
    p.cases[3][3] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[5][3] = Triangle_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[3][5] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][5] = Triangle_Sud;
    p.cases[1][2] = Triangle_Sud;
    p.cases[7][4] = Triangle_Sud;

    b.x = 2;
    b.y = 2;
    c.x = 2;
    c.y = 0;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 1\n");
        }
    }

    b.x = 4;
    b.y = 6;
    c.x = 4;
    c.y = 8;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 2\n");
        }
    }
}

void test_sauts_mult_Carre(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Carre_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[1][4] = Triangle_Sud;
    p.cases[4][7] = Triangle_Sud;

    b.x = 4;
    b.y = 2;
    c.x = 4;
    c.y = 0;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut carre multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut carre 1\n");
        }
    }

    b.x = 6;
    b.y = 4;
    c.x = 8;
    c.y = 4;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut carre multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut carre 2\n");
        }
    }
}

void test_sauts_mult_Losange(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Losange_Sud;
    p.cases[3][3] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[5][3] = Triangle_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[3][5] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][5] = Triangle_Sud;
    p.cases[7][1] = Triangle_Sud;
    p.cases[1][7] = Triangle_Sud;

    b.x = 2;
    b.y = 6;
    c.x = 0;
    c.y = 8;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut losange multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut losange 1\n");
        }
    }

    b.x = 6;
    b.y = 2;
    c.x = 8;
    c.y = 0;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut losange multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut losange 2\n");
        }
    }
}

void test_sauts_mult_Triangle_Sud(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Sud;
    p.cases[3][3] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[5][3] = Triangle_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[3][5] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][5] = Triangle_Sud;
    p.cases[1][1] = Triangle_Sud;
    p.cases[7][4] = Triangle_Sud;

    b.x = 2;
    b.y = 2;
    c.x = 0;
    c.y = 0;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 1\n");
        }
    }

    b.x = 4;
    b.y = 6;
    c.x = 4;
    c.y = 8;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 2\n");
        }
    }
}

void test_sauts_mult_Triangle_Nord(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Nord;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Nord;
    p.cases[3][3] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[5][3] = Triangle_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[3][5] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][5] = Triangle_Sud;
    p.cases[7][7] = Triangle_Sud;
    p.cases[7][1] = Triangle_Sud;

    b.x = 6;
    b.y = 6;
    c.x = 8;
    c.y = 8;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 1\n");
        }
    }

    b.x = 2;
    b.y = 6;
    c.x = 0;
    c.y = 8;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 2\n");
        }
    }
}

void test_sauts_mult_Triangle_Est(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Est;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Est;
    p.cases[3][3] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[5][3] = Triangle_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[3][5] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][5] = Triangle_Sud;
    p.cases[1][1] = Triangle_Sud;
    p.cases[4][7] = Triangle_Sud;

    b.x = 2;
    b.y = 2;
    c.x = 0;
    c.y = 0;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 1\n");
        }
    }

    b.x = 6;
    b.y = 4;
    c.x = 8;
    c.y = 4;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 2\n");
        }
    }
}

void test_sauts_mult_Triangle_Ouest(void)
{
    Plateau p;
    Coord a, b, c;
    Joueur joueur;
    joueur = Ouest;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Ouest;
    p.cases[3][3] = Triangle_Sud;
    p.cases[4][3] = Triangle_Sud;
    p.cases[5][3] = Triangle_Sud;
    p.cases[3][4] = Triangle_Sud;
    p.cases[5][4] = Triangle_Sud;
    p.cases[3][5] = Triangle_Sud;
    p.cases[4][5] = Triangle_Sud;
    p.cases[5][5] = Triangle_Sud;
    p.cases[1][7] = Triangle_Sud;
    p.cases[7][7] = Triangle_Sud;

    b.x = 6;
    b.y = 2;
    c.x = 8;
    c.y = 0;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 1\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 1\n");
        }
    }

    b.x = 6;
    b.y = 6;
    c.x = 8;
    c.y = 8;
    if (detection_des_sauts(joueur, a, b, &p))
    {
        if (regle_saut(&p, a, b))
        {
            if (regle_saut(&p, b, c))
            {
            }
            else
            {
                printf("ERREUR saut rond multiple 2\n");
            }
        }
        else
        {
            printf("ERREUR saut rond 2\n");
        }
    }
}
