#include "traverse.h"
#include <stdio.h>
#include <stdlib.h>

void init_plateau_vide(Plateau *p) {
  Case a;
  a = vide;
  int i, j;
  for (i = 0; i < 10; ++i) {
    for (j = 0; j < 10; ++j) {
      p->cases[i][j] = a;
    }
  }
}

void plateau_copie_dans(Plateau *porigine, Plateau *pdestination) {
  for (int i = 0; i < 10; ++i) {
    for (int j = 0; j < 10; ++j) {
      pdestination->cases[i][j] = porigine->cases[i][j];
    }
  }
}

void plateau_init(Plateau *p, int nombre_j) {
  for (int i = 0; i < 10; ++i) {
    for (int j = 0; j < 10; ++j) {
      p->cases[i][j] = vide;
    }
  }
  p->cases[0][1] = Carre_Nord;
  p->cases[0][2] = Triangle_Nord;
  p->cases[0][3] = Losange_Nord;
  p->cases[0][4] = Rond_Nord;
  p->cases[0][5] = Rond_Nord;
  ;
  p->cases[0][6] = Losange_Nord;
  p->cases[0][7] = Triangle_Nord;
  p->cases[0][8] = Carre_Nord;

  p->cases[9][1] = Carre_Sud;
  p->cases[9][2] = Triangle_Sud;
  p->cases[9][3] = Losange_Sud;
  p->cases[9][4] = Rond_Sud;
  p->cases[9][5] = Rond_Sud;
  p->cases[9][6] = Losange_Sud;
  p->cases[9][7] = Triangle_Sud;
  p->cases[9][8] = Carre_Sud;
  if (nombre_j == 4) {
    p->cases[1][0] = Carre_Ouest;
    p->cases[2][0] = Triangle_Ouest;
    p->cases[3][0] = Losange_Ouest;
    p->cases[4][0] = Rond_Ouest;
    p->cases[5][0] = Rond_Ouest;
    p->cases[6][0] = Losange_Ouest;
    p->cases[7][0] = Triangle_Ouest;
    p->cases[8][0] = Carre_Ouest;

    p->cases[1][9] = Carre_Est;
    p->cases[2][9] = Triangle_Est;
    p->cases[3][9] = Losange_Est;
    p->cases[4][9] = Rond_Est;
    p->cases[5][9] = Rond_Est;
    p->cases[6][9] = Losange_Est;
    p->cases[7][9] = Triangle_Est;
    p->cases[8][9] = Carre_Est;
  }
}

void plateau_print(Plateau *p) {
  for (int i = 0; i < 10; ++i) {
    printf("%d ", i);
    for (int j = 0; j < 10; ++j) {
      switch (p->cases[i][j]) {
      case vide:
        printf(" . ");
        break;
      case Rond_Sud:
        printf("RS ");
        break;
      case Triangle_Sud:
        printf("TS ");
        break;
      case Losange_Sud:
        printf("LS ");
        break;
      case Carre_Sud:
        printf("CS ");
        break;
      case Rond_Nord:
        printf("RN ");
        break;
      case Triangle_Nord:
        printf("TN ");
        break;
      case Losange_Nord:
        printf("LN ");
        break;
      case Carre_Nord:
        printf("CN ");
        break;
      case Rond_Est:
        printf("RE ");
        break;
      case Triangle_Est:
        printf("TE ");
        break;
      case Losange_Est:
        printf("LE ");
        break;
      case Carre_Est:
        printf("CE ");
        break;
      case Rond_Ouest:
        printf("RO ");
        break;
      case Triangle_Ouest:
        printf("TO ");
        break;
      case Losange_Ouest:
        printf("LO ");
        break;
      case Carre_Ouest:
        printf("CO ");
        break;
      default:
        printf("...");
        break;
      }
    }
    printf("\n");
  }
}

void partie_init(Partie *partie, int nombre) {
  partie->nombre_j = nombre;
  plateau_init(&partie->plateau, nombre);
  partie->joueur = Sud;
  sauvegarde_init(&partie->sauvegarde);
  partie->tour.n = 0;
  partie->ia[Sud] = 0;
  partie->ia[Nord] = 0;
  partie->ia[Est] = 0;
  partie->ia[Ouest] = 0;
  partie->etat_partie = Joue;
}
