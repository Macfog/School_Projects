#include <stdio.h>
#include <stdlib.h>
#include "traverse.h"
#include "Test.h"


int main(void)
{
   Plateau p;
   // Coord a;
   int nombre_j;
   nombre_j = 2;
   plateau_init(&p, nombre_j);
   // a.x = 0;
   // a.y = 1;
   // Case c = p.cases[a.x][a.y];
   // b.x = 1;
   // b.y = 1;

   /*
   if(!((p.cases[a.x][a.y] != vide)&&(p.cases[b.x][b.y] == vide))) printf("ERRR1\n");
   coup(&p,a,b);
   if(!((p.cases[a.x][a.y] == vide)&&(p.cases[b.x][b.y] == c))) printf("ERRR2\n");
   */

   if (!test_saisie("12 34 56"))
      printf("ERRR3\n");
   if (test_saisie("12 34 5"))
      printf("ERRR4\n");
   if (test_saisie("12 34 5a"))
      printf("ERRR5\n");
   if (!test_saisie("12 36"))
      printf("ERRR6\n");
   if (!test_saisie("12 36\n"))
      printf("ERRR7\n");

   //SauvegardePlateau * sav =  copie_plateau(&p);
   //plateau_print(&sav->plateau);
   //free(sav);
   //return 0;

   test_coup_Carre();
   test_coup_Rond();
   test_coup_Losange();
   test_coup_Triangle_Sud();
   test_coup_Triangle_Nord();
   test_coup_Triangle_Est();
   test_coup_Triangle_Ouest();

   test_sauts_Carre();
   test_sauts_Rond();
   test_sauts_Triangle_Sud();
   test_sauts_Triangle_Nord();
   test_sauts_Triangle_Est();
   test_sauts_Triangle_Ouest();
   test_sauts_Losange();

   test_sauts_mult_Rond();
   test_sauts_mult_Carre();
   test_sauts_mult_Losange();
   test_sauts_mult_Triangle_Ouest();
   test_sauts_mult_Triangle_Est();
   test_sauts_mult_Triangle_Sud();
   test_sauts_mult_Triangle_Nord();

   //test_coups_possibles_sauts_depuis();
   //test_coups_possibles_cas1();
   //test_coups_possibles_cas3();
   //test_coups_possibles_cas2();


    test_defaite_Sud();
    test_defaite_Nord ();
    test_defaite_Est ();
    test_defaite_Ouest ();

}
