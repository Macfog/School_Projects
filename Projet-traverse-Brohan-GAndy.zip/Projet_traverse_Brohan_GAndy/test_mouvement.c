#include <stdio.h>
#include <stdlib.h>
#include "traverse.h"
#include "Test.h"



void test_coup_Carre(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Carre_Sud;
    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if (((b.y==3||b.y==5)&&b.x==4) || (b.y==4&&(b.x==3||b.x==5)))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
               printf("ERREUR mouvement carre faux accepte \n");
            }

            }

        }
    b.y = 5;
    b.x = 4;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement carre correcte refuse (4.4 a x=4 y=5) \n");
    }

    b.y = 3;
    b.x = 4;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement carre correcte refuse (4.4 a x=4 y=3) \n");
    }

    b.y = 4;
    b.x = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement carre correcte refuse (4.4 a x=5 y=4) \n");
    }

    b.y = 4;
    b.x = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement carre correcte refuse (4.4 a x=3 y=4) \n");
    }

}


void test_coup_Rond(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Rond_Sud;

    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if ( ( b.x==3&&(b.y==3||b.y==5||b.y==4)) || (b.x==4&&(b.y==3||b.y==5)) || (b.x==5&&(b.y==3||b.y==4||b.y==5)))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
                if (b.x==4 && b.y==4)
                {
                    printf("ERREUR mouvement sur place du rond accepte\n");
                }
                else
                {
                     printf("ERREUR mouvement rond faux accepte en position : %d%d\n",b.y,b.x);
                }

            }

            }

        }

    b.x = 3;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=3 y=3) \n");
    }

    b.x = 3;
    b.y = 4;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=3 y=4) \n");
    }

    b.x = 3;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=3 y=5) \n");
    }

    b.x = 4;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=4 y=3) \n");
    }

    b.x = 4;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
         printf("ERREUR mouvement rond correcte refuse (4.4 a x=4 y=5) \n");
    }

    b.x = 5;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=5 y=3) \n");
    }

    b.x = 5;
    b.y = 4;
    if (!regle(joueur, a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=5 y=4) \n");
    }

    b.x = 5;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement rond correcte refuse (4.4 a x=5 y=5) \n");
    }


}


void test_coup_Losange(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Losange_Sud;
    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if ( ( b.x==3&&(b.y==3||b.y==5)) || (b.x==5&&(b.y==3||b.y==5)))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
               printf("ERREUR mouvement losange faux accepte (4.4 a x=%d y=%d) \n ",b.x,b.y);
            }

        }

    }

    b.x = 3;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement losange correcte refuse (4.4 a x=3 y=3) \n");
    }

    b.x = 3;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement losange correcte refuse (4.4 a x=3 y=5) \n");
    }

    b.x = 5;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement losange correcte refuse (4.4 a x=5 y=3) \n");
    }

    b.x = 5;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement losange correcte refuse (4.4 a x=5 y=5) \n");
    }

}


void test_coup_Triangle_Sud(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Sud;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Sud;
    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if ( ( b.x==3&&b.y==3) || (b.x==5&&b.y==3) || (b.x==4&&b.y==5))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
               printf("ERREUR mouvement triangle Sud faux accepte (4.4 a x=%d y=%d) \n",b.x,b.y);
            }

        }

    }


    b.x = 3;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Sud correcte refuse (4.4 a x=3 y=3) \n");
    }


    b.x = 5;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Sud correcte refuse (4.4 a x=5 y=3) \n");
    }


    b.x = 4;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
         printf("ERREUR mouvement triangle Sud correcte refuse (4.4 a x=4 y=5) \n");
    }
}

void test_coup_Triangle_Nord(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Nord;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Nord;
    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if ( ( b.x==3&&b.y==5) || (b.x==5&&b.y==5) || (b.x==4&&b.y==3))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
               printf("ERREUR mouvement triangle Nord faux accepte (4.4 a x=%d y=%d) \n",b.x,b.y);
            }

        }

    }


    b.x = 3;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Nord correcte refuse (4.4 a x=3 y=3) \n");
    }


    b.x = 5;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Nord correcte refuse (4.4 a x=5 y=3) \n");
    }


    b.x = 4;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
         printf("ERREUR mouvement triangle Nord correcte refuse (4.4 a x=4 y=5) \n");
    }
}

void test_coup_Triangle_Ouest(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Ouest;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Ouest;
    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if ( ( b.x==3&&b.y==4) || (b.x==5&&b.y==3) || (b.x==5&&b.y==5))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
               printf("ERREUR mouvement triangle Ouest faux accepte (4.4 a x=%d y=%d) \n",b.x,b.y);
            }

        }

    }


    b.x = 3;
    b.y = 4;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Ouest correcte refuse (4.4 a x=3 y=3) \n");
    }


    b.x = 5;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Ouest correcte refuse (4.4 a x=5 y=3) \n");
    }


    b.x = 5;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
         printf("ERREUR mouvement triangle Ouest correcte refuse (4.4 a x=4 y=5) \n");
    }
}

void test_coup_Triangle_Est(void){
    int n,v;
    Plateau p;
    Coord a,b;
    Joueur joueur;
    joueur = Est;
    a.x = 4;
    a.y = 4;
    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Triangle_Est;
    for(n=0; n<=9;++n)
    {
        b.y = n;
        for(v=0;v<=9;++v)
        {
            b.x = v;
            if ( ( b.x==5&&b.y==4) || (b.x==3&&b.y==3) || (b.x==3&&b.y==5))
            {

            }
            else if (regle(joueur, a, b, &p))
            {
               printf("ERREUR mouvement triangle Est faux accepte (4.4 a x=%d y=%d) \n",b.x,b.y);
            }

        }

    }


    b.x = 3;
    b.y = 3;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Est correcte refuse (4.4 a x=3 y=3) \n");
    }


    b.x = 5;
    b.y = 4;
    if (!regle(joueur,a,b,&p))
    {
        printf("ERREUR mouvement triangle Est correcte refuse (4.4 a x=5 y=3) \n");
    }


    b.x = 3;
    b.y = 5;
    if (!regle(joueur,a,b,&p))
    {
         printf("ERREUR mouvement triangle Est correcte refuse (4.4 a x=4 y=5) \n");
    }
}
