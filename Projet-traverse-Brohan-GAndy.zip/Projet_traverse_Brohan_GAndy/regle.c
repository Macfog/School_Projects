#include "traverse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int regle(Joueur joueur, Coord a, Coord b, Plateau *p) {
  Case piece = p->cases[a.y][a.x];
  if (piece == vide) {
    return 0;
  }
  if (p->cases[b.y][b.x] != vide) {
    return 0;
  }
  switch (joueur) {
  case Sud:
    if (!piece_is_sud(piece))
      return 0;
    break;
  case Nord:
    if (!piece_is_nord(piece))
      return 0;
    break;
  case Est:
    if (!piece_is_est(piece))
      return 0;
    break;
  case Ouest:
    if (!piece_is_ouest(piece))
      return 0;
    break;
  default:
    abort();
    break;
  }
  if (piece_is_rond(piece)) {
    if (MAX(abs(a.x - b.x), abs(a.y - b.y)) == 1)
      return 1;
    else
      return 0;
  }
  if (piece_is_carre(piece)) {
    if (MIN(abs(a.x - b.x), abs(a.y - b.y)) == 0 &&
        MAX(abs(a.x - b.x), abs(a.y - b.y)) == 1)
      return 1;
    else
      return 0;
  }
  if (piece_is_losange(piece)) {
    if (((b.y == a.y - 1) && ((b.x == a.x - 1) || (b.x == a.x + 1))) ||
        ((b.y == a.y + 1) && ((b.x == a.x - 1) || (b.x == a.x + 1))))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_nord(piece)) {
    if ((b.y == a.y - 1 && b.x == a.x) ||
        (b.y == a.y + 1 && abs(a.x - b.x) == 1))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_sud(piece)) {
    if ((b.y == a.y + 1 && b.x == a.x) ||
        (b.y == a.y - 1 && abs(a.x - b.x) == 1))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_est(piece)) {
    if (((b.y == a.y) && (b.x == a.x + 1)) ||
        ((b.y == a.y + 1) && (b.x == a.x - 1)) ||
        ((b.y == a.y - 1) && (b.x == a.x - 1)))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_ouest(piece)) {
    if (((b.y == a.y) && (b.x == a.x - 1)) ||
        ((b.y == a.y - 1) && (b.x == a.x + 1)) ||
        ((b.y == a.y + 1) && (b.x == a.x + 1)))
      return 1;
    else
      return 0;
  }
  return 1;
}

int detection_des_sauts(Joueur joueur, Coord a, Coord b, Plateau *p) {

  Case piece = p->cases[a.y][a.x];
  if (piece == vide) {
    return 0;
  }

  switch (joueur) {
  case Sud:
    if (!piece_is_sud(piece))
      return 0;
    break;
  case Nord:
    if (!piece_is_nord(piece))
      return 0;
    break;
  case Est:
    if (!piece_is_est(piece))
      return 0;
    break;
  case Ouest:
    if (!piece_is_ouest(piece))
      return 0;
    break;
  default:
    abort();
    break;
  }
  return detection_des_sauts_destination(piece, a, b, p);
}

int detection_des_sauts_destination(Case piece, Coord a, Coord b, Plateau *p) {

  if (p->cases[b.y][b.x] != vide) {
    return 0;
  }
  if (piece_is_rond(piece)) {
    if ((MIN(abs(b.x - a.x), abs(b.y - a.y)) == 0 &&
         MAX(abs(a.x - b.x), abs(a.y - b.y)) == 2) ||
        (MIN(abs(b.x - a.x), abs(b.y - a.y)) == 2 &&
         MAX(abs(a.x - b.x), abs(a.y - b.y)) == 2))
      return 1;
    else
      return 0;
  }
  if (piece_is_carre(piece)) {
    if ((MIN(abs(b.x - a.x), abs(b.y - a.y)) == 0 &&
         MAX(abs(a.x - b.x), abs(a.y - b.y)) == 2))
      return 1;
    else
      return 0;
  }
  if (piece_is_losange(piece)) {
    if ((MIN(abs(b.x - a.x), abs(b.y - a.y)) == 2 &&
         MAX(abs(a.x - b.x), abs(a.y - b.y)) == 2))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_nord(piece)) {
    if (((b.y == (a.y - 2) && b.x == a.x) ||
         (b.y == (a.y + 2) && abs(b.x - a.x) == 2)))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_sud(piece)) {
    if (((b.y == (a.y + 2) && b.x == a.x) ||
         (b.y == (a.y - 2) && abs(b.x - a.x) == 2)))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_ouest(piece)) {
    if (((b.y == a.y) && (b.x == a.x - 2)) ||
        ((b.y == a.y - 2) && (b.x == a.x + 2)) ||
        ((b.y == a.y + 2) && (b.x == a.x + 2)))
      return 1;
    else
      return 0;
  }
  if (piece_is_triangle_est(piece)) {
    if (((b.x == a.x - 2) && (b.y == a.y - 2)) ||
        ((b.x == a.x + 2) && (b.y == a.y)) ||
        ((b.x == a.x - 2) && (b.y == a.y + 2)))
      return 1;
    else
      return 0;
  }
  return 1;
}

int regle_saut(Plateau *p, Coord a, Coord b) {
  Coord c;
  c.x = (b.x + a.x) / 2;
  c.y = (b.y + a.y) / 2;
  if (p->cases[c.y][c.x] == vide)
    return 0;
  if (p->cases[b.y][b.x] != vide)
    return 0;

  return 1;
}

int bordure(Coord b, Joueur joueur) {
  if (joueur == Sud && ((b.y == 9) || (b.x == 0) || (b.x == 9) ))
    return 0;
  if (joueur == Nord && ((b.y == 0) || (b.x == 0) || (b.x == 9) ))
    return 0;
  if (joueur == Ouest && ((b.x == 0) || (b.y == 0) || (b.y == 9) ))
    return 0;
  if (joueur == Est && ((b.x == 9) || (b.y == 0) || (b.y == 9) ))
    return 0;
  return 1;
}

int est_arrivee(Coord b, Joueur joueur) {
  if (joueur == Sud && b.y == 0)
    return 1;
  if (joueur == Nord && b.y == 9)
    return 1;
  if (joueur == Ouest && b.x == 9)
    return 1;
  if (joueur == Est && b.x == 0)
    return 1;
  return 0;
}


char coup_valide(Joueur joueur, Plateau *p, int n, char *buf_tmp, Coord *a,
                 Coord *b) {
  if (n < 2)
    return 0;

  if (n == 2) {
    a->x = buf_tmp[0] - '0';
    a->y = buf_tmp[1] - '0';
    b->x = buf_tmp[3] - '0';
    b->y = buf_tmp[4] - '0';

    if (!detection_des_sauts(joueur, *a, *b, p)) // si ce n'est pas un saut
    {
      if (!regle(joueur, *a, *b, p)) {
        printf("Mauvais coup recommencez1!\n");
        return 0;
      }
    } else

        if (!regle_saut(p, *a, *b)) {
      printf("Mauvais coup recommencez2!\n");
      return 0;
    }
  } else {
    Case c = vide;
    for (int i = 0; i < n - 1; ++i) {
      a->x = buf_tmp[i * 3 + 0] - '0';
      a->y = buf_tmp[i * 3 + 1] - '0';
      b->x = buf_tmp[i * 3 + 3] - '0';
      b->y = buf_tmp[i * 3 + 4] - '0';

      if (i == 0) {
        c = p->cases[a->y][a->x];
        if (!detection_des_sauts(joueur, *a, *b, p)) {
          printf("Mauvais coup recommencez3!\n");
          return 0;
        }
      } else if (!detection_des_sauts_destination(c, *a, *b, p)) {
        printf("Mauvais coup recommencez3b!\n");
        return 0;
      }
      if (!regle_saut(p, *a, *b)) {
        printf("Mauvais coup recommencez4!\n");
        return 0;
      }
    }
    a->x = buf_tmp[0] - '0';
    a->y = buf_tmp[1] - '0';
  }
  return 1;
}
