#include "traverse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// defaite du joueur si il a toujours des pieces dans sa zone de départ apres le
// tour 31
int defaite(Plateau *p, Tour tour, Joueur joueur) {
  int i;

  if (tour.n > 30) {
    for (i = 0; i <= 9; ++i) {
      switch (joueur) {
      case Sud:
        if (piece_is_sud(p->cases[9][i])) {
          return 1;
        }
        break;
      case Nord:
        if (piece_is_nord(p->cases[0][i])) {
          return 1;
        }
        break;
      case Ouest:
        if (piece_is_ouest(p->cases[i][0])) {
          return 1;
        }
        break;
      case Est:
        if (piece_is_est(p->cases[i][9])) {
          return 1;
        }
        break;
      default:
        break;
      }
    }
  }

  return 0;
}

// victoire d'un des joueurs si tous ses pions se trouvent dans la zone
// d'arrivée
int victoire(Plateau *p, Joueur joueur) {
  int i, n;
  n = 0;
  Case piece;
  switch (joueur) {
  case Sud:
    for (i = 1; i < 9; ++i) {
      piece = p->cases[0][i];
      if (!piece_is_sud(piece))
        return 0;
      else
        ++n;
    }
    if (n == 8) {
      return 1;
    }
    break;
  case Nord:
    for (i = 1; i < 9; ++i) {
      piece = p->cases[9][i];
      if (!piece_is_nord(piece))
        return 0;
      else
        ++n;
    }
    if (n == 8) {
      return 1;
    }
    break;
  case Ouest:
    for (i = 1; i < 9; ++i) {
      piece = p->cases[i][9];
      if (!piece_is_ouest(piece))
        return 0;
      else
        ++n;
    }
    if (n == 8) {
      return 1;
    }
    break;
  case Est:
    for (i = 1; i < 9; ++i) {
      piece = p->cases[i][0];
      if (!piece_is_est(piece))
        return 0;
      else
        ++n;
    }
    if (n == 8) {
      return 1;
    }
    break;
  default:
    abort();
    break;
  }
  return 0;
}
