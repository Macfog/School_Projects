#ifndef __TRAVERSE_TEST_H__
#define __TRAVERSE_TEST_H__

#include <stdio.h>
#include <stdlib.h>


//test des déplacements simples
void test_coup_Rond();
void test_coup_Carre();
void test_coup_Losange();
void test_coup_Triangle_Sud();
void test_coup_Triangle_Nord();
void test_coup_Triangle_Est();
void test_coup_Triangle_Ouest();

//test des sauts simples
void test_sauts_Losange();
void test_sauts_Carre();
void test_sauts_Rond();
void test_sauts_Triangle_Sud();
void test_sauts_Triangle_Nord();
void test_sauts_Triangle_Est();
void test_sauts_Triangle_Ouest();

//test des sauts mutiples
void test_sauts_mult_Rond();
void test_sauts_mult_Carre();
void test_sauts_mult_Losange();
void test_sauts_mult_Triangle_Ouest();
void test_sauts_mult_Triangle_Est();
void test_sauts_mult_Triangle_Sud();
void test_sauts_mult_Triangle_Nord();

void test_coups_possibles_sauts_depuis();
void test_coups_possibles_cas1();
void test_coups_possibles_cas3();
void test_coups_possibles_cas2();

void test_defaite_Sud();
void test_defaite_Nord ();
void test_defaite_Est ();
void test_defaite_Ouest ();


#endif
