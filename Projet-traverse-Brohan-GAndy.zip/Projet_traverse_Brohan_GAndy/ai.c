#include "traverse.h"
#define DST_VICTOIRE_IMPOSSIBLE 1000

float eval_position(Plateau *plateau, Joueur joueur) {
  float dst_joueur = 0;
  for (int j = 0; j < 10; ++j) {
    for (int i = 0; i < 10; ++i) {
      Case c = plateau->cases[j][i];
      switch (joueur) {
      case Sud:
        if (piece_is_sud(c)) {
          dst_joueur += (j == 9) ? 2 * j : j;
        }
        break;
      case Nord:
        if (piece_is_nord(c)) {
          dst_joueur += (j == 0) ? 9 * 2 : j;
        }
        break;
      case Est:
        if (piece_is_est(c)) {
          dst_joueur += (i == 9) ? 2 * i : i;
        }
        break;
      case Ouest:
        if (piece_is_ouest(c)) {
          dst_joueur += (i == 0) ? 9 * 2 : 9 - i;
        }
        break;
      default:
        break;
      }
    }
  }

  return dst_joueur;
}

float eval_position2(Plateau *plateau, Joueur joueur) {
  float dst_joueur_sud = 0;
  float dst_joueur_nord = 0;
  float dst_joueur_est = 0;
  float dst_joueur_ouest = 0;
  for (int j = 0; j < 10; ++j) {
    for (int i = 0; i < 10; ++i) {
      Case c = plateau->cases[j][i];
      if (piece_is_sud(c)) {
        int min_dst = DST_VICTOIRE_IMPOSSIBLE;
        int new_dst = DST_VICTOIRE_IMPOSSIBLE;
        for (int dest = 0; dest < 8; ++dest) {
          Case cdest = plateau->cases[0][1 + dest];
          // if(cdest == vide) {
          if ((i == 1 + dest) && (j == 0))
            min_dst = 0;

          if (!piece_is_sud(cdest)) {
            if (piece_is_rond(c)) {
              new_dst = MAX(abs(i - (1 + dest)), 0 + j);
            } else if (piece_is_carre(c)) {
              new_dst = abs(i - (1 + dest)) + (0 + j);
            } else if (piece_is_losange(c)) {
              if ((abs(i - (1 + dest)) + (0 + j)) % 2 == 0) {
                new_dst = MAX(abs(i - (1 + dest)), 0 + j);
              } else {
                new_dst = DST_VICTOIRE_IMPOSSIBLE;
              }
            } else { // triangle
              new_dst = MAX(abs(i - (1 + dest)), 0 + j);
              if ((abs(i - (1 + dest)) + (0 + j)) % 2 == 0) {
              } else {
                new_dst += 2;
              }
            }
            if (new_dst < min_dst) {
              min_dst = new_dst;
            }
          }
        }
        if (min_dst == 0) {
          dst_joueur_sud -= 5;
        } else {
          dst_joueur_sud += (j == 9) ? 9 * 2 : min_dst;
        }
      } else if (piece_is_nord(c)) {
        int min_dst = DST_VICTOIRE_IMPOSSIBLE;
        int new_dst = DST_VICTOIRE_IMPOSSIBLE;
        for (int dest = 0; dest < 8; ++dest) {
          Case cdest = plateau->cases[9][1 + dest];
          // if(cdest == vide) {
          if ((i == 1 + dest) && (j == 9))
            min_dst = 0;

          if (!piece_is_nord(cdest)) {
            if (piece_is_rond(c)) {
              new_dst = MAX(abs(i - (1 + dest)), 9 - j);
            } else if (piece_is_carre(c)) {
              new_dst = abs(i - (1 + dest)) + (9 - j);
            } else if (piece_is_losange(c)) {
              if ((abs(i - (1 + dest)) + (9 - j)) % 2 == 0) {
                new_dst = MAX(abs(i - (1 + dest)), 9 - j);
              } else {
                new_dst = DST_VICTOIRE_IMPOSSIBLE;
              }
            } else { // triangle
              new_dst = MAX(abs(i - (1 + dest)), 9 - j);
              if ((abs(i - (1 + dest)) + (9 - j)) % 2 == 0) {
              } else {
                new_dst += 2;
              }
            }
            if (new_dst < min_dst) {
              min_dst = new_dst;
            }
          }
        }
        if (min_dst == 0) {
          dst_joueur_nord -= 5;
        } else {
          dst_joueur_nord += (j == 0) ? 9 * 2 : min_dst;
        }
      } else if (piece_is_est(c)) {
        int min_dst = DST_VICTOIRE_IMPOSSIBLE;
        int new_dst = DST_VICTOIRE_IMPOSSIBLE;
        for (int dest = 0; dest < 8; ++dest) {
          Case cdest = plateau->cases[1 + dest][0];
          // if(cdest == vide) {
          if ((j == 1 + dest) && (i == 0))
            min_dst = 0;

          if (!piece_is_est(cdest)) {
            if (piece_is_rond(c)) {
              new_dst = MAX(abs(j - (1 + dest)), 0 + i);
            } else if (piece_is_carre(c)) {
              new_dst = abs(j - (1 + dest)) + (0 + i);
            } else if (piece_is_losange(c)) {
              if ((abs(j - (1 + dest)) + (0 + i)) % 2 == 0) {
                new_dst = MAX(abs(j - (1 + dest)), 0 + i);
              } else {
                new_dst = DST_VICTOIRE_IMPOSSIBLE;
              }
            } else { // triangle
              new_dst = MAX(abs(i - (1 + dest)), 0 + 1);
              if ((abs(i - (1 + dest)) + (0 + j)) % 2 == 0) {
              } else {
                new_dst += 2;
              }
            }
            if (new_dst < min_dst) {
              min_dst = new_dst;
            }
          }
        }
        if (min_dst == 0) {
          dst_joueur_est -= 5;
        } else {
          dst_joueur_est += (i == 9) ? 9 * 2 : min_dst;
        }
      } else if (piece_is_ouest(c)) {
        int min_dst = DST_VICTOIRE_IMPOSSIBLE;
        int new_dst = DST_VICTOIRE_IMPOSSIBLE;
        for (int dest = 0; dest < 8; ++dest) {
          Case cdest = plateau->cases[1 + dest][9];
          // if(cdest == vide) {
          if ((j == 1 + dest) && (i == 9))
            min_dst = 0;

          if (!piece_is_ouest(cdest)) {
            if (piece_is_rond(c)) {
              new_dst = MAX(abs(j - (1 + dest)), 9 - i);
            } else if (piece_is_carre(c)) {
              new_dst = abs(j - (1 + dest)) + (9 - i);
            } else if (piece_is_losange(c)) {
              if ((abs(j - (1 + dest)) + (9 - i)) % 2 == 0) {
                new_dst = MAX(abs(j - (1 + dest)), 9 - i);
              } else {
                new_dst = DST_VICTOIRE_IMPOSSIBLE;
              }
            } else { // triangle
              new_dst = MAX(abs(j - (1 + dest)), 9 - i);
              if ((abs(j - (1 + dest)) + (9 - i)) % 2 == 0) {
              } else {
                new_dst += 2;
              }
            }
            if (new_dst < min_dst) {
              min_dst = new_dst;
            }
          }
        }
        if (min_dst == 0) {
          dst_joueur_ouest -= 5;
        } else {
          dst_joueur_ouest += (i == 0) ? 9 * 2 : min_dst;
        }
      }
    }
  }
  // float dst_min = MIN(dst_joueur_sud, dst_joueur_nord);
  switch (joueur) {
  case Sud:
    return dst_joueur_sud;
    // return (dst_joueur_sud - dst_joueur_nord) / (dst_joueur_sud - dst_min +
    // dst_joueur_nord - dst_min);
    break;
  case Nord:
    return dst_joueur_nord;
    //    return (dst_joueur_nord -dst_joueur_sud)/ (dst_joueur_sud - dst_min +
    //    dst_joueur_nord - dst_min);
    break;
  case Est:
    return dst_joueur_est;
    break;
  case Ouest:
    return dst_joueur_ouest;
    break;
  default:
    return 0;
    break;
  }
  return 0;
}

char ia_joue(Partie *partie) {
  CoupsPossibles coups_possibles;
  coups_possibles_init(&coups_possibles);

  coups_possibles_joueur(&partie->plateau, partie->joueur, &coups_possibles);
  float meilleur_eval = 100000000;

  Plateau plateau_eval;
  int meilleur_coup = 0;
  float orig_eval = eval_position2(&partie->plateau, partie->joueur);
  for (int i = 0; i < coups_possibles.ncoups; ++i) {
    plateau_copie_dans(&partie->plateau, &plateau_eval);
    coup(&plateau_eval, coups_possibles.tcoups[i].depart,
         coups_possibles.tcoups[i].arrivee);
    float cur_eval = eval_position2(&plateau_eval, partie->joueur);
    if ((cur_eval >= 1000) ||
        ((orig_eval >= cur_eval) &&
         (!est_arrivee(coups_possibles.tcoups[i].depart, partie->joueur)))) {
      if (cur_eval < meilleur_eval) {
        meilleur_eval = cur_eval;
        meilleur_coup = i;
      }

      if (cur_eval == meilleur_eval && rand() % 2) {
        meilleur_coup = i;
      }
    }
    // printf("%i %i %i %i %f\n", coups_possibles.tcoups[i].depart.x,
    //        coups_possibles.tcoups[i].depart.y,
    //        coups_possibles.tcoups[i].arrivee.x,
    //        coups_possibles.tcoups[i].arrivee.y, cur_eval);
  }
  if (coups_possibles.ncoups > 0) {
    int idx = meilleur_coup;
    Coord dep = coups_possibles.tcoups[idx].depart;
    Coord arr = coups_possibles.tcoups[idx].arrivee;
    char buf[10];
    buf[0] = '0' + dep.x;
    buf[1] = '0' + dep.y;
    buf[2] = ' ';
    buf[3] = '0' + arr.x;
    buf[4] = '0' + arr.y;
    buf[5] = 0;
    // print_joueur(partie->joueur, partie->nombre_j);
    // printf(" tour %i joue %s\n", partie->tour.n, buf);
    // plateau_print(&partie->plateau);
    fflush(stdin);
    if (joue(buf, 2, partie) == 1) {
      partie->etat_partie = Fin;
    }
  }
  // coups_possibles_vide(coups_possibles);
  coups_possibles_free(&coups_possibles);
  return 1;
}

char ia_joue_test_min_max_2j_minmax_pour_nord(Partie *partie) {
  CoupsPossibles coups_possibles;
  coups_possibles_init(&coups_possibles);
  CoupsPossibles coups_possibles2;
  coups_possibles_init(&coups_possibles2);

  coups_possibles_joueur(&partie->plateau, partie->joueur, &coups_possibles);
  float meilleur_eval = 100000000;
  float pire_eval2 = -100000000;

  Plateau plateau_eval;
  int meilleur_coup = 0;
  float orig_eval = eval_position2(&partie->plateau, partie->joueur);
  for (int i = 0; i < coups_possibles.ncoups; ++i) {
    plateau_copie_dans(&partie->plateau, &plateau_eval);
    coup(&plateau_eval, coups_possibles.tcoups[i].depart,
         coups_possibles.tcoups[i].arrivee);
    float cur_eval = eval_position2(&plateau_eval, partie->joueur);
    coups_possibles_joueur(&partie->plateau, partie->joueur, &coups_possibles2);
    float meilleur_eval2 = 100000000;
    Plateau plateau_eval2;
    Tour tour;
    Joueur joueur2 = joueur_qui_joue(partie->joueur, &tour, partie->nombre_j);
    if (partie->joueur == Nord)
      for (int i = 0; i < coups_possibles2.ncoups; ++i) {
        plateau_copie_dans(&plateau_eval, &plateau_eval2);
        coup(&plateau_eval2, coups_possibles2.tcoups[i].depart,
             coups_possibles2.tcoups[i].arrivee);
        float cur_eval2 = eval_position2(&plateau_eval, joueur2);
        if ((cur_eval2 >= 1000) ||
            ((cur_eval >= cur_eval2) &&
             (!est_arrivee(coups_possibles2.tcoups[i].depart, joueur2)))) {
          if (cur_eval2 < meilleur_eval2) {
            meilleur_eval2 = cur_eval2;
          }

        }
      }
    if ((cur_eval >= 1000) ||
        ((orig_eval >= cur_eval) &&
         (!est_arrivee(coups_possibles.tcoups[i].depart, partie->joueur)))) {
      if (cur_eval < meilleur_eval && (meilleur_eval2 >= pire_eval2)) {
        pire_eval2 = meilleur_eval2;
        meilleur_eval = cur_eval;
        meilleur_coup = i;
      }

      if (cur_eval == meilleur_eval && rand() % 2) {
        meilleur_coup = i;
      }
    }
    // printf("%i %i %i %i %f\n", coups_possibles.tcoups[i].depart.x,
    //        coups_possibles.tcoups[i].depart.y,
    //        coups_possibles.tcoups[i].arrivee.x,
    //        coups_possibles.tcoups[i].arrivee.y, cur_eval);
  }
  if (coups_possibles.ncoups > 0) {
    int idx = meilleur_coup;
    Coord dep = coups_possibles.tcoups[idx].depart;
    Coord arr = coups_possibles.tcoups[idx].arrivee;
    char buf[10];
    buf[0] = '0' + dep.x;
    buf[1] = '0' + dep.y;
    buf[2] = ' ';
    buf[3] = '0' + arr.x;
    buf[4] = '0' + arr.y;
    buf[5] = 0;
    // print_joueur(partie->joueur, partie->nombre_j);
    // printf(" tour %i joue %s\n", partie->tour.n, buf);
    // plateau_print(&partie->plateau);
    fflush(stdin);
    if (joue(buf, 2, partie) == 1) {
      partie->etat_partie = Fin;
    }
  }
  // coups_possibles_vide(coups_possibles);
  coups_possibles_free(&coups_possibles);
  return 1;
}