#include "traverse_gui.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <math.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14156
#endif

SDL_Window *win = NULL;
SDL_Renderer *ren = NULL;
int w_largeur = 640;
int w_hauteur = 480;
typedef struct {
  int x;
  int y;
} Coordgraph;

typedef struct {
  char r;
  char g;
  char b;

} CouleurTraverse;

CouleurTraverse couleur_sud = {(char)255, (char)0, (char)0};
CouleurTraverse couleur_nord = {(char)0, (char)0, (char)255};
CouleurTraverse couleur_est = {(char)0, (char)255, (char)0};
CouleurTraverse couleur_ouest = {(char)255, (char)255, (char)0};
SDL_Color texte_color = {0, 0, 0, 255};

enum EtatGui {
  ChoixMode,
  ChoixIASud,
  ChoixIANord,
  ChoixIAEst,
  ChoixIAOuest,
  AttenteDepart,
  AttenteDestination,
  AttenteSautSupplementaire,
  FinPartie,
} etat_gui;

typedef enum {
  ModeJ2 = 0,
  ModeJ4,
  VictoireSud,
  VictoireNord,
  VictoireOuest,
  VictoireEst,
  DefaiteSud,
  DefaiteNord,
  DefaiteOuest,
  DefaiteEst,
  JoueSud,
  JoueNord,
  JoueOuest,
  JoueEst,
  Nulle,
  Passe,
  NouvellePartie,
  IASud,
  IANord,
  IAOuest,
  IAEst,
  Oui,
  Non,
  Error,
  FinMessage
} MessagesGui;

SDL_Surface *surfaceMessages[FinMessage];

float deg2rad(float a) { return (a * M_PI) / 180.; }

void render_rond(int cx, int cy) {
  int cote = (w_hauteur > w_largeur ? w_largeur : w_hauteur) / 10;
  int px = cx * cote + cote / 2;
  int py = cy * cote + cote / 2;
  float r = (cote * 0.8) / 2;
  float r2 = r * r;
  for (int y = 0; y <= r; ++y) {
    int x = sqrt(r2 - y * y);
    SDL_RenderDrawLine(ren, px - x, py - y, px + x, py - y);
    SDL_RenderDrawLine(ren, px - x, py + y, px + x, py + y);
  }

  //        SDL_SetRenderDrawColor(ren,0,0,0,255);
}

void render_triangle_sud(int cx, int cy) {
  int cote = (w_hauteur > w_largeur ? w_largeur : w_hauteur) / 10;
  int base_d_x = cx * cote + cote / 8;
  int base_d_y = cy * cote + cote * 7 / 8;
  int base_a_x = cx * cote + cote * 7 / 8;
  int base_a_y = cy * cote + cote * 7 / 8;

  int hypo1_d_x = cx * cote + cote / 8;
  int hypo1_d_y = cy * cote + cote * 7 / 8;
  int hypo1_a_x = cx * cote + cote / 2;
  int hypo1_a_y = cy * cote + cote / 8;

  int hypo2_d_x = cx * cote + cote / 2;
  int hypo2_d_y = cy * cote + cote / 8;
  int hypo2_a_x = cx * cote + cote * 7 / 8;
  int hypo2_a_y = cy * cote + cote * 7 / 8;

  SDL_RenderDrawLine(ren, base_d_x, base_d_y, base_a_x, base_a_y);
  SDL_RenderDrawLine(ren, hypo1_d_x, hypo1_d_y, hypo1_a_x, hypo1_a_y);
  SDL_RenderDrawLine(ren, hypo2_d_x, hypo2_d_y, hypo2_a_x, hypo2_a_y);
  Coordgraph i, j;
  int n;
  n = 0;
  i.x = hypo2_d_x;
  i.y = hypo2_d_y;
  j.x = hypo2_d_x;
  j.y = hypo2_d_y;
  for (; i.y <= hypo2_a_y; ++i.y) {
    SDL_RenderDrawLine(ren, i.x, i.y, j.x, j.y);
    ++j.y;
    ++n;
    if (n % 2) {
      ++j.x;
    }
  }
  i.x = hypo2_d_x;
  i.y = hypo2_d_y;
  j.x = hypo2_d_x;
  j.y = hypo2_d_y;
  for (; i.y <= hypo2_a_y; ++i.y) {
    SDL_RenderDrawLine(ren, i.x, i.y, j.x, j.y);
    ++j.y;
    ++n;
    if (n % 2) {
      j.x = j.x - 1;
    }
  }
}

void render_losange(int cx, int cy) {
  int cote = (w_hauteur > w_largeur ? w_largeur : w_hauteur) / 10;
  int cote1_d_x = cx * cote + cote / 2;
  int cote1_d_y = cy * cote + cote / 8;
  int cote1_a_x = cx * cote + cote * 7 / 8;
  int cote1_a_y = cy * cote + cote / 2;

  int cote2_d_x = cx * cote + cote * 7 / 8;
  int cote2_d_y = cy * cote + cote / 2;
  int cote2_a_x = cx * cote + cote / 2;
  int cote2_a_y = cy * cote + cote * 7 / 8;

  int cote3_d_x = cx * cote + cote / 2;
  int cote3_d_y = cy * cote + cote * 7 / 8;
  int cote3_a_x = cx * cote + cote / 8;
  int cote3_a_y = cy * cote + cote / 2;

  int cote4_d_x = cx * cote + cote / 8;
  int cote4_d_y = cy * cote + cote / 2;
  int cote4_a_x = cx * cote + cote / 2;
  int cote4_a_y = cy * cote + cote / 8;

  SDL_RenderDrawLine(ren, cote1_d_x, cote1_d_y, cote1_a_x, cote1_a_y);
  SDL_RenderDrawLine(ren, cote2_d_x, cote2_d_y, cote2_a_x, cote2_a_y);
  SDL_RenderDrawLine(ren, cote3_d_x, cote3_d_y, cote3_a_x, cote3_a_y);
  SDL_RenderDrawLine(ren, cote4_d_x, cote4_d_y, cote4_a_x, cote4_a_y);
  Coordgraph i, j;
  i.x = cote1_d_x;
  i.y = cote1_d_y;
  j.x = cote1_d_x;
  j.y = cote1_d_y;
  for (; i.y <= cote1_a_y; ++i.y) {
    SDL_RenderDrawLine(ren, i.x, i.y, j.x, j.y);
    ++j.y;
    ++j.x;
  }
  i.x = cote1_d_x;
  i.y = cote1_d_y;
  j.x = cote1_d_x;
  j.y = cote1_d_y;
  for (; i.y <= cote1_a_y; ++i.y) {
    SDL_RenderDrawLine(ren, i.x, i.y, j.x, j.y);
    ++j.y;
    --j.x;
  }
  i.x = cote3_a_x;
  i.y = cote3_a_y;
  j.x = cote1_a_x;
  j.y = cote1_a_y;
  for (; i.y <= cote2_a_y; ++i.y) {
    SDL_RenderDrawLine(ren, i.x, i.y, j.x, j.y);
    ++i.x;
    --j.x;
    ++j.y;
  }
}

void render_carre(int cx, int cy) {
  int cote = (w_hauteur > w_largeur ? w_largeur : w_hauteur) / 10;
  SDL_Rect carre;
  carre.x = cx * cote + cote / 8;
  carre.y = cy * cote + cote / 8;
  carre.w = cote * 6 / 8;
  carre.h = cote * 6 / 8;
  SDL_RenderFillRect(ren, &carre);
}

void render_plateau(Plateau *p, CoupsPossibles *coups_possibles) {
  int cote = (w_hauteur > w_largeur ? w_largeur : w_hauteur) / 10;
  SDL_Rect rect;
  rect.w = cote;
  rect.h = cote;
  for (int i = 0; i < 10; ++i) {
    for (int j = 0; j < 10; ++j) {
      rect.x = i * cote;
      rect.y = j * cote;
      if ((i + j) % 2)
        SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
      else
        SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
      SDL_RenderFillRect(ren, &rect);
    }
  }

  for (int j = 0; j < 10; ++j) {
    for (int i = 0; i < 10; ++i) {
      Case c = p->cases[j][i];

      if (piece_is_nord(c)) {
        SDL_SetRenderDrawColor(ren, couleur_nord.r, couleur_nord.g,
                               couleur_nord.b, 255);
      } else if (piece_is_sud(c)) {
        SDL_SetRenderDrawColor(ren, couleur_sud.r, couleur_sud.g, couleur_sud.b,
                               255);
      } else if (piece_is_est(c)) {
        SDL_SetRenderDrawColor(ren, couleur_est.r, couleur_est.g, couleur_est.b,
                               255);
      } else if (piece_is_ouest(c)) {
        SDL_SetRenderDrawColor(ren, couleur_ouest.r, couleur_ouest.g,
                               couleur_ouest.b, 255);
      }
      if (piece_is_carre(c)) {
        render_carre(i, j);
      } else if (piece_is_losange(c)) {
        render_losange(i, j);
      } else if (piece_is_rond(c)) {
        render_rond(i, j);
      } else if (piece_is_triangle_sud(c)) {
        render_triangle_sud(i, j);
      } else if (piece_is_triangle_nord(c)) {
        render_triangle_sud(i, j);
      } else if (piece_is_triangle_est(c)) {
        render_triangle_sud(i, j);
      } else if (piece_is_triangle_ouest(c)) {
        render_triangle_sud(i, j);
      }
    }
  }
  if (coups_possibles != NULL) {
    SDL_SetRenderDrawColor(ren, 128, 128, 128, 55);
    for (int i = 0; i < coups_possibles->ncoups; ++i) {
      rect.x = coups_possibles->tcoups[i].arrivee.x * cote;
      rect.y = coups_possibles->tcoups[i].arrivee.y * cote;
      SDL_RenderFillRect(ren, &rect);
    }
  }
  SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
}

SDL_Rect print_message(MessagesGui m, int x, int y, char button) {
  SDL_Texture *Message = SDL_CreateTextureFromSurface(
      ren, surfaceMessages[m]); // sert à convertir le message en texture

  SDL_Rect Message_rect; // creer un rectagle
  Message_rect.x = x;    // controls the rect's x coordinate
  Message_rect.y = y;    // controls the rect's y coordinte
  Message_rect.w = surfaceMessages[m]->w + 4; // controls the width of the rect
  Message_rect.h = surfaceMessages[m]->h + 4; // controls the height of the rect
  SDL_SetRenderDrawColor(ren, 100, 100, 100, 255);
  SDL_RenderFillRect(ren, &Message_rect);
  SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
  if (button)
    SDL_RenderDrawRect(ren, &Message_rect);
  SDL_Rect cadre;
  cadre.x = x + 2;
  cadre.y = y + 2;
  cadre.w = surfaceMessages[m]->w;
  cadre.h = surfaceMessages[m]->h;
  SDL_RenderCopy(ren, Message, NULL,
                 &cadre); // you put the renderer's name first, the Message, the
                          // crop size(you can ignore this if you don't want to
                          // dabble with cropping), and the rect which is the
                          // size and coordinate of your texture

  // SDL_FreeSurface(surfaceMessage);
  SDL_DestroyTexture(Message);

  return Message_rect;
}

char init_gui() {
  etat_gui = ChoixMode; // AttenteDepart;
  {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
      printf("SDL_Init Error: %s\n", SDL_GetError());
      return 0;
    }
    if (TTF_Init() != 0) {
      printf("TTF_Init erreur %s\n", TTF_GetError());
      SDL_Quit();
      return 0;
    }

    TTF_Font *font =
        TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSans.ttf", 20);
    if (font == NULL) {
      printf("TTF_OpenFont erreur %s\n", TTF_GetError());
      font = TTF_OpenFont("font/FreeSans.ttf", 25);
    }
    if (font == NULL) {
      printf("TTF_OpenFont erreur %s\n", TTF_GetError());
      TTF_Quit();
      SDL_Quit();
      return 0;
    }
    surfaceMessages[ModeJ2] =
        TTF_RenderText_Blended(font, "Mode 2 joueurs", texte_color);
    surfaceMessages[ModeJ4] =
        TTF_RenderText_Blended(font, "Mode 4 joueurs", texte_color);
    surfaceMessages[VictoireSud] =
        TTF_RenderText_Blended(font, "Victoire Sud", texte_color);
    surfaceMessages[VictoireNord] =
        TTF_RenderText_Blended(font, "Victoire Nord", texte_color);
    surfaceMessages[VictoireOuest] =
        TTF_RenderText_Blended(font, "Victoire Ouest", texte_color);
    surfaceMessages[VictoireEst] =
        TTF_RenderText_Blended(font, "Victoire Est", texte_color);
    surfaceMessages[DefaiteSud] =
        TTF_RenderText_Blended(font, "Defaite de Sud", texte_color);
    surfaceMessages[DefaiteNord] =
        TTF_RenderText_Blended(font, "Defaite de Nord", texte_color);
    surfaceMessages[DefaiteOuest] =
        TTF_RenderText_Blended(font, "Defaite de Ouest", texte_color);
    surfaceMessages[DefaiteEst] =
        TTF_RenderText_Blended(font, "Defaite de Est", texte_color);
    surfaceMessages[JoueSud] =
        TTF_RenderText_Blended(font, "Joueur Sud", texte_color);
    surfaceMessages[JoueNord] =
        TTF_RenderText_Blended(font, "Joueur Nord", texte_color);
    surfaceMessages[JoueOuest] =
        TTF_RenderText_Blended(font, "Joueur Ouest", texte_color);
    surfaceMessages[JoueEst] =
        TTF_RenderText_Blended(font, "Joueur Est", texte_color);
    surfaceMessages[Nulle] = TTF_RenderText_Blended(font, "Nulle", texte_color);
    surfaceMessages[Passe] = TTF_RenderText_Blended(font, "Passe", texte_color);
    surfaceMessages[NouvellePartie] =
        TTF_RenderText_Blended(font, "Nouvelle Partie", texte_color);
    surfaceMessages[IASud] = TTF_RenderText_Blended(font, "IASud", texte_color);
    surfaceMessages[IANord] =
        TTF_RenderText_Blended(font, "IANord", texte_color);
    surfaceMessages[IAOuest] =
        TTF_RenderText_Blended(font, "IAOuest", texte_color);
    surfaceMessages[IAEst] = TTF_RenderText_Blended(font, "IAEst", texte_color);
    surfaceMessages[Oui] = TTF_RenderText_Blended(font, "Oui", texte_color);
    surfaceMessages[Non] = TTF_RenderText_Blended(font, "Non", texte_color);
    surfaceMessages[Error] = TTF_RenderText_Blended(font, "Error", texte_color);
    TTF_CloseFont(font);

    win = SDL_CreateWindow("Traverse", 100, 100, w_largeur, w_hauteur,
                           SDL_WINDOW_SHOWN);
    // Make sure creating our window went ok
    if (win == NULL) {
      printf("SDL_CreateWindow Error: %s\n", SDL_GetError());

      free_tous_messages();
      TTF_Quit();
      SDL_Quit();

      return 0;
    }

    ren = SDL_CreateRenderer(
        win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (ren == NULL) {
      SDL_DestroyWindow(win);
      win = NULL;
      printf("SDL_CreateRenderer Error: %s", SDL_GetError());
      free_tous_messages();
      TTF_Quit();
      SDL_Quit();
      return 0;
    }
  }
  return 1;
}

void free_tous_messages() {
  for (int i = 0; i < FinMessage; ++i) {
    SDL_FreeSurface(surfaceMessages[i]);
  }
}
char stop_gui() {
  free_tous_messages();

  SDL_DestroyRenderer(ren);
  SDL_DestroyWindow(win);
  TTF_Quit();
  SDL_Quit();

  return 1;
}

char step_gui_choix_mode(Partie *partie) {
  SDL_Event e;
  char quit = 0;
  SDL_Rect r1 = print_message(ModeJ2, 50, 200, 1);
  SDL_Rect r2 = print_message(ModeJ4, r1.x + r1.w + 10, 200, 1);

  // etat_gui = AttenteDepart;
  // partie_init(partie, 2);
  // partie->ia[0] = 1;
  // partie->ia[1] = 1;
  // partie->ia[2] = 1;
  // partie->ia[3] = 1;
  // return 0;
  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {

    // If user closes the window
    if (e.type == SDL_QUIT) {
      quit = 1;
    }
    if (etat_gui == ChoixMode) {
      if (e.type == SDL_MOUSEBUTTONDOWN) {
        SDL_Point point;
        point.x = e.button.x;
        point.y = e.button.y;
        if (SDL_PointInRect(&point, &r1)) {
          etat_gui = ChoixIASud;
          partie_init(partie, 2);
        } else if (SDL_PointInRect(&point, &r2)) {

          etat_gui = ChoixIASud;
          partie_init(partie, 4);
        }
      }
    }
  }

  return quit;
}

char step_gui_choix_ia(Partie *partie) {
  SDL_Event e;
  char quit = 0;
  MessagesGui m = Error;
  int nia = Sud;
  enum EtatGui nextetat = AttenteDepart;
  if (etat_gui == ChoixIASud) {
    m = IASud;
    nia = Sud;
    nextetat = ChoixIANord;
  } else if (etat_gui == ChoixIANord) {
    m = IANord;
    nia = Nord;
    if (partie->nombre_j == 2) {
      nextetat = AttenteDepart;
    } else {
      nextetat = ChoixIAEst;
    }
  } else if (etat_gui == ChoixIAEst) {
    nia = Est;
    m = IAEst;
    nextetat = ChoixIAOuest;
  } else if (etat_gui == ChoixIAOuest) {
    nia = Ouest;

    m = IAOuest;
    nextetat = AttenteDepart;
  }
  print_message(m, 50, 100, 0);
  SDL_Rect r1 = print_message(Oui, 50, 200, 1);
  SDL_Rect r2 = print_message(Non, r1.x + r1.w + 10, 200, 1);
  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {

    // If user closes the window
    if (e.type == SDL_QUIT) {
      quit = 1;
    }
    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;
      if (SDL_PointInRect(&point, &r1)) {
        etat_gui = nextetat;
        partie->ia[nia] = 1;
      } else if (SDL_PointInRect(&point, &r2)) {

        etat_gui = nextetat;
        partie->ia[nia] = 0;
      }
    }
  }

  return quit;
}

char step_gui_joue(Partie *partie, CoupsPossibles *coups_possibles, char *buf,
                   int *n) {
  SDL_Event e;
  char quit = 0;
  render_plateau(&partie->plateau, coups_possibles);
  int cote = (w_hauteur > w_largeur ? w_largeur : w_hauteur) / 10;
  MessagesGui mjoueur = JoueSud;
  switch (partie->joueur) {
  case Sud:
    mjoueur = JoueSud;
    break;
  case Nord:
    mjoueur = JoueNord;
    break;
  case Ouest:
    mjoueur = JoueOuest;
    break;
  case Est:
    mjoueur = JoueEst;
    break;
  default:
    mjoueur = JoueSud;
    break;
  }
  SDL_Rect r1 = print_message(NouvellePartie, cote * 10 + 10, 100, 1);
  print_message(mjoueur, cote * 10 + 10, 10, 0);
  if (partie->ia[partie->joueur] == 0) {

    if (etat_gui == AttenteDepart) {
      coups_possibles_vide(coups_possibles);
      coups_possibles_joueur(&partie->plateau, partie->joueur, coups_possibles);
      if (coups_possibles->ncoups == 0) {
        printf("Pass\n");
        buf[0] = '0';
        buf[1] = '0';
        buf[2] = ' ';
        buf[3] = '0';
        buf[4] = '0';
        buf[5] = 0;
        if (joue(buf, 2, partie) == 1) {
          etat_gui = FinPartie;
        } else {
          etat_gui = AttenteDepart;
        }
        coups_possibles_vide(coups_possibles);
        return 0;
      }
      coups_possibles_vide(coups_possibles);
    }
  }
  while (SDL_PollEvent(&e)) {

    // If user closes the window
    if (e.type == SDL_QUIT) {
      quit = 1;
    }

    // If user presses any key
    if (e.type == SDL_KEYDOWN) {
      if (e.key.keysym.sym == SDLK_s) {
        sauvegarde_ecrit(&partie->sauvegarde, "p1.txt", partie->nombre_j);
      } else if (e.key.keysym.sym == SDLK_l) {
        sauvegarde_lit(&partie->sauvegarde, &partie->plateau, &partie->joueur,
                       "p1.txt", &partie->tour, &partie->nombre_j);
        etat_gui = ChoixIASud;
        return 0;
        //   plateau_print(&plateau);
      }
    }

    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;
      if (SDL_PointInRect(&point, &r1)) {
        etat_gui = ChoixMode;
        return 0;
      }
      if (partie->ia[partie->joueur] == 0) {

        unsigned int cx = e.button.x / cote;
        unsigned int cy = e.button.y / cote;
        if (cx < 10 && cy < 10) {
          if (etat_gui == AttenteDepart) {

            buf[0] = '0' + cx;
            buf[1] = '0' + cy;
            buf[2] = 0;
            etat_gui = AttenteDestination;
            *n = 1;
            Coord a = {cx, cy};
            coups_possibles_depuis(&partie->plateau, partie->joueur, a,
                                   coups_possibles);
            printf("n %i c %s\n", *n, buf);
          } else if (etat_gui == AttenteDestination) {
            buf[2] = ' ';
            buf[3] = '0' + cx;
            buf[4] = '0' + cy;
            buf[5] = 0;
            printf("n %i c %s\n", *n, buf);
            *n = 2;
            Coord a;
            Coord b;
            if (coup_valide(partie->joueur, &partie->plateau, *n, buf, &a,
                            &b)) {
              if (detection_des_sauts(partie->joueur, a, b, &partie->plateau)) {
                etat_gui = AttenteSautSupplementaire;
                coups_possibles_vide(coups_possibles);
              } else {
                if (joue(buf, *n, partie) == 1) {
                  etat_gui = FinPartie;
                } else {
                  etat_gui = AttenteDepart;
                }
                coups_possibles_vide(coups_possibles);
              }
            } else {
              etat_gui = AttenteDepart;
              coups_possibles_vide(coups_possibles);
            }
          } else if (etat_gui == AttenteSautSupplementaire) {
            if (e.button.button == SDL_BUTTON_LEFT) {
              buf[2 + (*n - 1) * 3] = ' ';
              buf[2 + (*n - 1) * 3 + 1] = '0' + cx;
              buf[2 + (*n - 1) * 3 + 2] = '0' + cy;
              buf[2 + (*n - 1) * 3 + 3] = 0;

              ++(*n);
              printf("n %i c %s\n", *n, buf);
            }
            Coord a;
            Coord b;
            if (coup_valide(partie->joueur, &partie->plateau, *n, buf, &a,
                            &b)) {
              if (e.button.button == SDL_BUTTON_RIGHT) {
                if (joue(buf, *n, partie) == 1) {
                  etat_gui = FinPartie;
                } else {
                  etat_gui = AttenteDepart;
                }
                coups_possibles_vide(coups_possibles);
              }
            } else {
              etat_gui = AttenteDepart;
            }
          }
        }
      }
    }
  }
  if (partie->ia[partie->joueur] == 1) {
    ia_joue(partie);
    if (partie->etat_partie == Fin) {
      //     sauvegarde_ecrit(&partie->sauvegarde, "fin.txt", partie->nombre_j);

      etat_gui = FinPartie;
    }
  }

  return quit;
}

char step_gui_fin_partie(Partie *partie) {
  render_plateau(&partie->plateau, NULL);
  // etat_gui = ChoixMode;
  // return 0;
  SDL_Event e;
  char quit = 0;
  MessagesGui message = FinMessage;
  if (victoire(&partie->plateau, partie->joueur)) {
    switch (partie->joueur) {
    case Sud:
      message = VictoireSud;
      break;
    case Nord:
      message = VictoireNord;
      break;
    case Est:
      message = VictoireEst;
      break;
    case Ouest:
      message = VictoireOuest;
      break;
    default:
      return 1;
      break;
    }
  } else if (defaite(&partie->plateau, partie->tour, partie->joueur)) {
    switch (partie->joueur) {
    case Sud:
      message = DefaiteSud;
      break;
    case Nord:
      message = DefaiteNord;
      break;
    case Est:
      message = DefaiteEst;
      break;
    case Ouest:
      message = DefaiteOuest;
      break;
    default:
      return 1;
      break;
    }
  } else if (sauvegarde_plateau_existe_2_fois(&partie->sauvegarde,
                                              &partie->plateau)) {
    message = Nulle;
  }

  SDL_Rect r1 = print_message(message, 200, 200, 1);
  while (SDL_PollEvent(&e)) {

    // If user closes the window
    if (e.type == SDL_QUIT) {
      quit = 1;
    }
    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;
      if (SDL_PointInRect(&point, &r1)) {
        etat_gui = ChoixMode;
      }
    }
  }
  return quit;
}

char run_gui() {
  Partie partie;
  char buf[1024];
  int n = 0;

  // For tracking if we want to quit
  CoupsPossibles coups_possibles;
  coups_possibles_init(&coups_possibles);
  int quit = 0;
  while (!quit) {
    SDL_SetRenderDrawColor(ren, 0, 0, 0, 0);

    SDL_RenderClear(ren);

    if (etat_gui == ChoixMode) {
      quit = step_gui_choix_mode(&partie);
    } else if (etat_gui == ChoixIASud) {
      quit = step_gui_choix_ia(&partie);
    } else if (etat_gui == ChoixIANord) {
      quit = step_gui_choix_ia(&partie);
    } else if (etat_gui == ChoixIAEst) {
      quit = step_gui_choix_ia(&partie);
    } else if (etat_gui == ChoixIAOuest) {
      quit = step_gui_choix_ia(&partie);
    } else if (etat_gui == FinPartie) {
      quit = step_gui_fin_partie(&partie);
    } else {
      quit = step_gui_joue(&partie, &coups_possibles, buf, &n);
    }
    // printf("Render\n");
    SDL_RenderPresent(ren);
    // SDL_Delay(10);
  }
  coups_possibles_free(&coups_possibles);
  return 0;
}
