#include "traverse.h"
#include "Test.h"


//fonction testant le fonctionnement de la detection et de la proposition des coups pouvant etre joues
void test_coups_possibles_sauts_depuis()
{
    Plateau p;
    Coord a;
    a.x = 4;
    a.y = 4;

    CoupsPossibles coups_possibles;
    coups_possibles_init(&coups_possibles);

    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Carre_Sud;
    p.cases[a.y][a.x + 1] = Carre_Nord;
    coups_possibles_sauts_depuis(&p, Sud, a, &coups_possibles);
    if (coups_possibles.ncoups != 1)
    {
        printf("Erreur1 test_coups_possibles_sauts_depuis\n");
    }
    else
    {
        if (!((coups_possibles.tcoups[0].arrivee.x == a.x + 2) && (coups_possibles.tcoups[0].arrivee.y == a.y)))
        {
            printf("Erreur1b test_coups_possibles_sauts_depuis\n");
        }
    }
    coups_possibles_vide(&coups_possibles);
    if (coups_possibles.ncoups != 0)
    {
        printf("Erreur2 test_coups_possibles_sauts_depuis\n");
    }

    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Carre_Sud;
    p.cases[a.y][a.x - 1] = Carre_Nord;
    coups_possibles_sauts_depuis(&p, Sud, a, &coups_possibles);
    if (coups_possibles.ncoups != 1)
    {
        printf("Erreur3 test_coups_possibles_sauts_depuis\n");
    }
    else
    {
        if (!((coups_possibles.tcoups[0].arrivee.x == a.x - 2) && (coups_possibles.tcoups[0].arrivee.y == a.y)))
        {
            printf("Erreur3b test_coups_possibles_sauts_depuis\n");
        }
    }
    coups_possibles_vide(&coups_possibles);

    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Carre_Sud;
    p.cases[a.y - 1][a.x] = Carre_Nord;
    coups_possibles_sauts_depuis(&p, Sud, a, &coups_possibles);
    if (coups_possibles.ncoups != 1)
    {
        printf("Erreur4 test_coups_possibles_sauts_depuis\n");
    }
    else
    {
        if (!((coups_possibles.tcoups[0].arrivee.x == a.x) && (coups_possibles.tcoups[0].arrivee.y == a.y - 2)))
        {
            printf("Erreur4b test_coups_possibles_sauts_depuis\n");
        }
    }
    coups_possibles_vide(&coups_possibles);

    init_plateau_vide(&p);
    p.cases[a.y][a.x] = Carre_Sud;
    p.cases[a.y + 1][a.x] = Carre_Nord;
    coups_possibles_sauts_depuis(&p, Sud, a, &coups_possibles);
    if (coups_possibles.ncoups != 1)
    {
        printf("Erreur5 test_coups_possibles_sauts_depuis\n");
    }
    else
    {
        if (!((coups_possibles.tcoups[0].arrivee.x == a.x) && (coups_possibles.tcoups[0].arrivee.y == a.y + 2)))
        {
            printf("Erreur5b test_coups_possibles_sauts_depuis\n");
        }
    }
    coups_possibles_vide(&coups_possibles);

    coups_possibles_free(&coups_possibles);
}

void test_coups_possibles_cas1()
{
    Plateau p;

    CoupsPossibles coups_possibles;
    coups_possibles_init(&coups_possibles);

    plateau_init(&p, 2);
    Coord a = {1, 9};
    Coord b = {4, 2};

    coup(&p, a, b);
    a.x = 5;
    a.y = 0;
    b.x = 5;
    b.y = 2;
    coup(&p, a, b);
    a.x = 6;
    a.y = 0;
    b.x = 6;
    b.y = 1;
    coup(&p, a, b);

    plateau_print(&p);
    coups_possibles_joueur(&p,Nord,&coups_possibles);
    // a.x = 5;
    // a.y = 0;
    // coups_possibles_depuis(&p, Nord, a, &coups_possibles);

    for (int i = 0; i < coups_possibles.ncoups; ++i)
    {
        printf("%i %i %i %i\n", coups_possibles.tcoups[i].depart.x, coups_possibles.tcoups[i].depart.y,
               coups_possibles.tcoups[i].arrivee.x, coups_possibles.tcoups[i].arrivee.y);
    }
    if(coup_valide(Sud,&p,3,"42 62 60",&a,&b) != 1) printf("ERRR test_coups_possibles_cas1\n");
}

void test_coups_possibles_cas3()
{
    Plateau p;

    CoupsPossibles coups_possibles;
    coups_possibles_init(&coups_possibles);

    plateau_init(&p, 2);
    Coord a = {1, 9};
    Coord b = {1, 7};

    coup(&p, a, b);
    a.x = 5;
    a.y = 0;
    b.x = 5;
    b.y = 1;
    coup(&p, a, b);
    plateau_print(&p);
    coups_possibles_joueur(&p,Nord,&coups_possibles);
    // a.x = 5;
    // a.y = 0;
    // coups_possibles_depuis(&p, Nord, a, &coups_possibles);

    for (int i = 0; i < coups_possibles.ncoups; ++i)
    {
        printf("%i %i %i %i\n", coups_possibles.tcoups[i].depart.x, coups_possibles.tcoups[i].depart.y,
               coups_possibles.tcoups[i].arrivee.x, coups_possibles.tcoups[i].arrivee.y);
    }
}
void test_coups_possibles_cas2()
{
    Plateau p;

    CoupsPossibles coups_possibles;
    coups_possibles_init(&coups_possibles);

    plateau_init(&p, 2);
    Coord a = {1, 9};
    Coord b = {1, 7};

    coup(&p, a, b);
    a.x = 3;
    a.y = 0;
    b.x = 2;
    b.y = 1;
    coup(&p, a, b);
    plateau_print(&p);
    coups_possibles_joueur(&p,Nord,&coups_possibles);
    // a.x = 5;
    // a.y = 0;
    // coups_possibles_depuis(&p, Nord, a, &coups_possibles);

    for (int i = 0; i < coups_possibles.ncoups; ++i)
    {
        printf("%i %i %i %i\n", coups_possibles.tcoups[i].depart.x, coups_possibles.tcoups[i].depart.y,
               coups_possibles.tcoups[i].arrivee.x, coups_possibles.tcoups[i].arrivee.y);
    }
}
