#include "traverse.h"

// initialisation de la liste des coups possibles
void coups_possibles_init(CoupsPossibles *coups_possibles) {
  coups_possibles->max_sz = 30;
  coups_possibles->ncoups = 0;
  coups_possibles->tcoups = malloc(coups_possibles->max_sz * sizeof(Coup));
}

// ajout d'un coup a la liste des coups possibles
void coups_possibles_add_coups(CoupsPossibles *coups_possibles, Coup coup) {
  if (coups_possibles->ncoups == coups_possibles->max_sz) {
    coups_possibles->max_sz *= 2;
    coups_possibles->tcoups = realloc(coups_possibles->tcoups,
                                      coups_possibles->max_sz * sizeof(Coup));
  }
  coups_possibles->tcoups[coups_possibles->ncoups] = coup;
  ++coups_possibles->ncoups;
}

void coups_possibles_free(CoupsPossibles *coups_possibles) {
  coups_possibles->max_sz = 0;
  coups_possibles->ncoups = 0;
  free(coups_possibles->tcoups);
}

void coups_possibles_vide(CoupsPossibles *coups_possibles) {
  coups_possibles->ncoups = 0;
}

// la fonction teste tous les deplacements possibles et leur applique les regles
// afin de determiner si le coup est jouable puis l'ajoute à la liste des coups
// possibles
void coups_possibles_depl_depuis(Plateau *plateau, Joueur joueur, Coord depart,
                                 CoupsPossibles *coups_possibles) {
  int ncoups_valides = coups_possibles->ncoups;
  Case c = plateau->cases[depart.y][depart.x];
  if (c == vide)
    return;
  if (piece_is_carre(c)) {
    if (depart.x >= 1) {
      Coord arrivee = {depart.x - 1, depart.y};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.y >= 1) {
      Coord arrivee = {depart.x, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9) {
      Coord arrivee = {depart.x + 1, depart.y};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.y < 9) {
      Coord arrivee = {depart.x, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  if (piece_is_losange(c)) {
    if (depart.x >= 1 && depart.y >= 1) {
      Coord arrivee = {depart.x - 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y < 9) {
      Coord arrivee = {depart.x - 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y >= 1) {
      Coord arrivee = {depart.x + 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y < 9) {
      Coord arrivee = {depart.x + 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  if (piece_is_rond(c)) {
    if (depart.x >= 1) {
      Coord arrivee = {depart.x - 1, depart.y};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.y >= 1) {
      Coord arrivee = {depart.x, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9) {
      Coord arrivee = {depart.x + 1, depart.y};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.y < 9) {
      Coord arrivee = {depart.x, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y >= 1) {
      Coord arrivee = {depart.x - 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y < 9) {
      Coord arrivee = {depart.x - 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y >= 1) {
      Coord arrivee = {depart.x + 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y < 9) {
      Coord arrivee = {depart.x + 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  if (piece_is_triangle_sud(c)) {
    if (depart.y < 9) {
      Coord arrivee = {depart.x, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y >= 1) {
      Coord arrivee = {depart.x + 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y >= 1) {
      Coord arrivee = {depart.x - 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  if (piece_is_triangle_nord(c)) {
    if (depart.y >= 1) {
      Coord arrivee = {depart.x, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y < 9) {
      Coord arrivee = {depart.x - 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y < 9) {
      Coord arrivee = {depart.x + 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  if (piece_is_triangle_est(c)) {
    if (depart.x < 9) {
      Coord arrivee = {depart.x + 1, depart.y};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y < 9) {
      Coord arrivee = {depart.x - 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x >= 1 && depart.y >= 1) {
      Coord arrivee = {depart.x - 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  if (piece_is_triangle_ouest(c)) {
    if (depart.x >= 1) {
      Coord arrivee = {depart.x - 1, depart.y};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y < 9) {
      Coord arrivee = {depart.x + 1, depart.y + 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
    if (depart.x < 9 && depart.y >= 1) {
      Coord arrivee = {depart.x + 1, depart.y - 1};
      Coup coup = {depart, arrivee};
      if (bordure(arrivee, joueur))
        coups_possibles_add_coups(coups_possibles, coup);
    }
  }

  for (int i = ncoups_valides; i < coups_possibles->ncoups; ++i) {
    if (regle(joueur, coups_possibles->tcoups[i].depart,
              coups_possibles->tcoups[i].arrivee, plateau)) {

      coups_possibles->tcoups[ncoups_valides] = coups_possibles->tcoups[i];
      ++ncoups_valides;
    }
  }
  coups_possibles->ncoups = ncoups_valides;
}

typedef struct {
  int nsaut;
  Coord saut[8];
} SautCoord;

SautCoord saut_carre = {4, {{2, 0}, {-2, 0}, {0, 2}, {0, -2}}};
SautCoord saut_lozange = {4, {{2, 2}, {-2, -2}, {-2, 2}, {2, -2}}};
SautCoord saut_rond = {
    8, {{2, 0}, {-2, 0}, {0, 2}, {0, -2}, {2, 2}, {-2, -2}, {-2, 2}, {2, -2}}};
SautCoord saut_triangle_sud = {3, {{0, 2}, {-2, -2}, {2, -2}}};
SautCoord saut_triangle_nord = {3, {{0, -2}, {-2, 2}, {2, 2}}};
SautCoord saut_triangle_est = {3, {{2, 0}, {-2, -2}, {-2, 2}}};
SautCoord saut_triangle_ouest = {3, {{-2, 0}, {2, -2}, {2, 2}}};

char sur_echiquier(Coord a) {
  return a.x >= 0 && a.x <= 9 && a.y >= 0 && a.y <= 9;
}

char sur_chemin(Coord a, Coord *chemin, int netape) {
  for (int i = 0; i < netape; ++i) {
    if (a.x == chemin[i].x && a.y == chemin[i].y)
      return 1;
  }
  return 0;
}

void coups_possibles_sauts_mult_chemin(Plateau *plateau, Joueur joueur,
                                       Case piece, Coord *chemin, int netape,
                                       CoupsPossibles *coups_possibles) {
  SautCoord *saut_piece = NULL;
  if (piece_is_carre(piece)) {
    saut_piece = &saut_carre;
  } else if (piece_is_losange(piece)) {
    saut_piece = &saut_lozange;
  } else if (piece_is_rond(piece)) {
    saut_piece = &saut_rond;
  } else if (piece_is_triangle_sud(piece)) {
    saut_piece = &saut_triangle_sud;
  } else if (piece_is_triangle_nord(piece)) {
    saut_piece = &saut_triangle_nord;
  } else if (piece_is_triangle_est(piece)) {
    saut_piece = &saut_triangle_est;
  } else if (piece_is_triangle_ouest(piece)) {
    saut_piece = &saut_triangle_ouest;
  }

  for (int i = 0; i < saut_piece->nsaut; ++i) {
    Coord arrivee = chemin[netape - 1];
    arrivee.x += saut_piece->saut[i].x;
    arrivee.y += saut_piece->saut[i].y;

    if (sur_echiquier(arrivee) &&
        regle_saut(plateau, chemin[netape - 1], arrivee)) {
      if (!sur_chemin(arrivee, chemin, netape)) {
        Coup coup = {chemin[netape - 1], arrivee};

        if (bordure(arrivee, joueur)) {
          coups_possibles_add_coups(coups_possibles, coup);
        }
        chemin[netape] = arrivee;
        coups_possibles_sauts_mult_chemin(plateau, joueur, piece, chemin,
                                          netape + 1, coups_possibles);
      }
    }
  }
}

// la fonction teste tous les sauts simples possibles et leur applique les
// regles afin de determiner si le coup est valable puis l'ajouter à la liste
// des coups possibles
void coups_possibles_sauts_depuis(Plateau *plateau, Joueur joueur, Coord depart,
                                  CoupsPossibles *coups_possibles) {
  //   int ncoups_valides = coups_possibles->ncoups;
  Case piece = plateau->cases[depart.y][depart.x];
  Coord chemin[100];
  chemin[0] = depart;
  coups_possibles_sauts_mult_chemin(plateau, joueur, piece, chemin, 1,
                                    coups_possibles);
}

// rassemble les deplacements et les sauts simples autorises
void coups_possibles_depuis(Plateau *plateau, Joueur joueur, Coord depart,
                            CoupsPossibles *coups_possibles) {
    Case piece = plateau->cases[depart.y][depart.x];
  switch (joueur) {
    case Sud:
      if (!piece_is_sud(piece)) {
        return;
      }
      break;
    case Nord:
      if (!piece_is_nord(piece)) {
        return;
      }
      break;
    case Est:
      if (!piece_is_est(piece)) {
        return;
      }
      break;
    case Ouest:
      if (!piece_is_ouest(piece)) {
        return;
      }
      break;
    default:
      return;
      break;
    }

    coups_possibles_depl_depuis(plateau, joueur, depart, coups_possibles);
    coups_possibles_sauts_depuis(plateau, joueur, depart, coups_possibles);
  }

  // fait la liste des coups autorises en fonction u joueur
  void coups_possibles_joueur(Plateau * plateau, Joueur joueur,
                              CoupsPossibles * coups_possibles) {
    for (int j = 0; j < 10; ++j) {
      for (int i = 0; i < 10; ++i) {
        Case c = plateau->cases[j][i];
        Coord depart = {i, j};
        switch (joueur) {
        case Sud:
          if (piece_is_sud(c)) {
            coups_possibles_depuis(plateau, joueur, depart, coups_possibles);
          }
          break;
        case Nord:
          if (piece_is_nord(c)) {
            coups_possibles_depuis(plateau, joueur, depart, coups_possibles);
          }
          break;
        case Est:
          if (piece_is_est(c)) {
            coups_possibles_depuis(plateau, joueur, depart, coups_possibles);
          }
          break;
        case Ouest:
          if (piece_is_ouest(c)) {
            coups_possibles_depuis(plateau, joueur, depart, coups_possibles);
          }
          break;
        default:
          break;
        }
      }
    }
  }
