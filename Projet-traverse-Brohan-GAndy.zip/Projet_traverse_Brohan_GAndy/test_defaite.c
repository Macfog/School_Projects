#include <stdio.h>
#include <stdlib.h>
#include "traverse.h"
#include "Test.h"

void test_defaite_Sud (){
    int n,v;
    Tour tour;
    tour.n = 31;
    Plateau p;
    Coord a;
    Joueur joueur;
    joueur = Sud;
    init_plateau_vide(&p);

    for(n=0; n<=9;++n)
    {
        a.y = n;
        for(v=0;v<=9;++v)
        {
            a.x = v;
            init_plateau_vide(&p);
            p.cases[a.y][a.x] = Carre_Sud;
            if (defaite(&p, tour, joueur))
            {
                if (a.y == 9)
                {

                }
                else
                {
                    printf("Erreur defaite Sud detecter au mauvaise endroit x=%d y=%d \n",a.x,a.y);
                }
            }
            else
            {
                if (a.y == 9)
                {
                    printf("Erreur non detecter Sud en x=%d y=%d \n", a.x, a.y);
                }
            }
        }


    }
}

void test_defaite_Nord (){
    int n,v;
    Tour tour;
    tour.n = 31;
    Plateau p;
    Coord a;
    Joueur joueur;
    joueur = Nord;
    init_plateau_vide(&p);

    for(n=0; n<=9;++n)
    {
        a.y = n;
        for(v=0;v<=9;++v)
        {
            a.x = v;
            init_plateau_vide(&p);
            p.cases[a.y][a.x] = Carre_Nord;
            if (defaite(&p,tour, joueur))
            {
                if (a.y == 0)
                {

                }
                else
                {
                    printf("Erreur defaite Nord detecter au mauvaise endroit x=%d y=%d \n",a.x,a.y);
                }
            }
            else
            {
                if (a.y == 0)
                {
                    printf("Erreur non detecter Nord en x=%d y=%d \n", a.x, a.y);
                }
            }
        }


    }
}

void test_defaite_Est (){
    int n,v;
    Tour tour;
    tour.n = 31;
    Plateau p;
    Coord a;
    Joueur joueur;
    joueur = Est;
    init_plateau_vide(&p);

    for(n=0; n<=9;++n)
    {
        a.y = n;
        for(v=0;v<=9;++v)
        {
            a.x = v;
            init_plateau_vide(&p);
            p.cases[a.y][a.x] = Carre_Est;
            if (defaite(&p,tour, joueur))
            {
                if (a.x == 9)
                {

                }
                else
                {
                    printf("Erreur defaite Est detecter au mauvaise endroit x=%d y=%d \n",a.x,a.y);
                }
            }
            else
            {
                if (a.x == 9)
                {
                    printf("Erreur non detecter Est en x=%d y=%d \n", a.x, a.y);
                }
            }
        }


    }
}

void test_defaite_Ouest (){
    int n,v;
    Tour tour;
    tour.n = 31;
    Plateau p;
    Coord a;
    Joueur joueur;
    joueur = Ouest;
    init_plateau_vide(&p);

    for(n=0; n<=9;++n)
    {
        a.y = n;
        for(v=0;v<=9;++v)
        {
            a.x = v;
            init_plateau_vide(&p);
            p.cases[a.y][a.x] = Carre_Ouest;
            if (defaite(&p,tour, joueur))
            {
                if (a.x == 0)
                {

                }
                else
                {
                    printf("Erreur defaite Ouest detecter au mauvaise endroit x=%d y=%d \n",a.x,a.y);
                }
            }
            else
            {
                if (a.x == 0)
                {
                    printf("Erreur non detecter Ouest en x=%d y=%d \n", a.x, a.y);
                }
            }
        }


    }
}
