#include "qwirkle.h"
#include <stdio.h>

Position premier_joueur(Partie *partie) {
  partie->joueur.position = Sud;

  Position meilleure_main = Sud;
  int max_main = 0;
  int t_couleur[6];
  int t_forme[6];
  int t_piece_unique[6 * 6];
  do {
    Jeu *main_joueur = main_courante(partie);
    for (int j = 0; j < 6 * 6; ++j) {
      t_piece_unique[j] = 0;
    }
    for (int j = 0; j < 6; ++j) {
      t_couleur[j] = 0;
      t_forme[j] = 0;
    }
    for (int j = 0; j < 6; ++j) {
      if (t_piece_unique[main_joueur->jeu[j].forme * 6 +
                         main_joueur->jeu[j].couleur - 1] != 0)
        continue;
      t_piece_unique[main_joueur->jeu[j].forme * 6 +
                     main_joueur->jeu[j].couleur - 1] = 1;
      ++t_couleur[main_joueur->jeu[j].couleur - 1];
      ++t_forme[main_joueur->jeu[j].forme];
    }
    int max_main_tmp = 0;
    for (int j = 0; j < 6; ++j) {
      if (t_couleur[j] > max_main_tmp) {
        max_main_tmp = t_couleur[j];
      }
      if (t_forme[j] > max_main_tmp) {
        max_main_tmp = t_forme[j];
      }
    }
    if (max_main_tmp > max_main) {
      max_main = max_main_tmp;
      meilleure_main = partie->joueur.position;
    }
    // printf("j %d, n %d\n", partie->joueur.position, max_main_tmp);
    partie->joueur.position = joueur_suivant(partie);
  } while (partie->joueur.position != Sud);
  partie->nb_piece_premier_tour = max_main;
  partie->joueur.position = meilleure_main;
  return meilleure_main;
}

// si la case n'est pas occupée
int verif_case_vide(Coord coord_plateau, Plateau *plateau) {
  if (get_cases_coord_plateau(plateau, coord_plateau.x, coord_plateau.y)
          .couleur != Vide) {
    return 0;
  }
  return 1;
}

// Il y a au moins une case occupée à coté
int verif_case_adjacente_non_vide(Coord coord_plateau, Plateau *plateau) {

  if ((get_cases_coord_plateau(plateau, coord_plateau.x - 1, coord_plateau.y)
           .couleur == Vide) &&
      (get_cases_coord_plateau(plateau, coord_plateau.x, coord_plateau.y - 1)
           .couleur == Vide) &&
      (get_cases_coord_plateau(plateau, coord_plateau.x + 1, coord_plateau.y)
           .couleur == Vide) &&
      (get_cases_coord_plateau(plateau, coord_plateau.x, coord_plateau.y + 1)
           .couleur == Vide)) {
    return 0;
  }
  return 1;
}

int regle_forme_couleur(Coord coord_plateau, Case piece, Plateau *plateau) {

  int n = 1;
  int x = coord_plateau.x;
  int y = coord_plateau.y;

  int t_couleur[6];
  int t_forme[6];
  int t_piece_unique[6 * 6];
  for (int j = 0; j < 6 * 6; ++j) {
    t_piece_unique[j] = 0;
  }
  for (int j = 0; j < 6; ++j) {
    t_couleur[j] = 0;
    t_forme[j] = 0;
  }

  while (get_cases_coord_plateau(plateau, x + n, y).couleur != Vide) {
    Case cur_piece = get_cases_coord_plateau(plateau, x + n, y);
    ++t_couleur[cur_piece.couleur - 1];
    ++t_forme[cur_piece.forme];
    ++t_piece_unique[cur_piece.forme * 6 + cur_piece.couleur - 1];
    ++n;
  }
  n = 1;
  while (get_cases_coord_plateau(plateau, x - n, y).couleur != Vide) {
    Case cur_piece = get_cases_coord_plateau(plateau, x - n, y);
    ++t_couleur[cur_piece.couleur - 1];
    ++t_forme[cur_piece.forme];
    ++t_piece_unique[cur_piece.forme * 6 + cur_piece.couleur - 1];
    ++n;
  }

  ++t_couleur[piece.couleur - 1];
  ++t_forme[piece.forme];
  ++t_piece_unique[piece.forme * 6 + piece.couleur - 1];

  int n_couleur = 0;
  int n_forme = 0;
  for (int j = 0; j < 6 * 6; ++j) {
    if (t_piece_unique[j] > 1)
      return 0;
  }
  for (int j = 0; j < 6; ++j) {
    if (t_couleur[j])
      ++n_couleur;
    if (t_forme[j])
      ++n_forme;
  }

  if (n_couleur > 1 && n_forme > 1)
    return 0;
  // Vertical
  for (int j = 0; j < 6 * 6; ++j) {
    t_piece_unique[j] = 0;
  }
  for (int j = 0; j < 6; ++j) {
    t_couleur[j] = 0;
    t_forme[j] = 0;
  }

  n = 1;
  while (get_cases_coord_plateau(plateau, x, y + n).couleur != Vide) {
    Case cur_piece = get_cases_coord_plateau(plateau, x, y + n);
    ++t_couleur[cur_piece.couleur - 1];
    ++t_forme[cur_piece.forme];
    ++t_piece_unique[cur_piece.forme * 6 + cur_piece.couleur - 1];
    ++n;
  }
  n = 1;
  while (get_cases_coord_plateau(plateau, x, y - n).couleur != Vide) {
    Case cur_piece = get_cases_coord_plateau(plateau, x, y - n);
    ++t_couleur[cur_piece.couleur - 1];
    ++t_forme[cur_piece.forme];
    ++t_piece_unique[cur_piece.forme * 6 + cur_piece.couleur - 1];
    ++n;
  }
  ++t_couleur[piece.couleur - 1];
  ++t_forme[piece.forme];
  ++t_piece_unique[piece.forme * 6 + piece.couleur - 1];

  n_couleur = 0;
  n_forme = 0;
  for (int j = 0; j < 6 * 6; ++j) {
    if (t_piece_unique[j] > 1)
      return 0;
  }
  for (int j = 0; j < 6; ++j) {
    if (t_couleur[j])
      ++n_couleur;
    if (t_forme[j])
      ++n_forme;
  }
  if (n_couleur > 1 && n_forme > 1)
    return 0;

  return 1;
}

int regle_pieces_jouees_alignees(Coord coord_plateau, Plateau *plateau,
                                 int nb_pieces_jouees, Coord *pos_jouees) {

  char meme_x = 1;
  char meme_y = 1;
  for (int i = 0; i < nb_pieces_jouees; ++i) {
    if (coord_plateau.x != pos_jouees[i].x)
      meme_x = 0;
    if (coord_plateau.y != pos_jouees[i].y)
      meme_y = 0;
  }
  if (meme_x == 0 && meme_y == 0)
    return 0;
  if (meme_y) {
    int min_x = coord_plateau.x;
    int max_x = coord_plateau.x;
    for (int i = 0; i < nb_pieces_jouees; ++i) {
      if (pos_jouees[i].x < min_x)
        min_x = pos_jouees[i].x;
      if (pos_jouees[i].x > max_x)
        max_x = pos_jouees[i].x;
    }
    for (int i = min_x; i <= max_x; ++i) {
      if (i == coord_plateau.x)
        continue;
      if (get_cases_coord_plateau(plateau, i, coord_plateau.y).couleur == Vide)
        return 0;
    }
  }
  if (meme_x) {
    int min_y = coord_plateau.y;
    int max_y = coord_plateau.y;
    for (int i = 0; i < nb_pieces_jouees; ++i) {
      if (pos_jouees[i].y < min_y)
        min_y = pos_jouees[i].y;
      if (pos_jouees[i].y > max_y)
        max_y = pos_jouees[i].y;
    }
    for (int i = min_y; i <= max_y; ++i) {
      if (i == coord_plateau.y)
        continue;
      if (get_cases_coord_plateau(plateau, coord_plateau.x, i).couleur == Vide)
        return 0;
    }
  }
  return 1;
}

// Vérification de toutes les règles
int regles(Coord coord_plateau, Case piece, Plateau *plateau,
           int nb_pieces_jouees, Coord *pos_jouees) {

  if (!verif_case_vide(coord_plateau, plateau)) {
    return 0;
  }
  if (!verif_case_adjacente_non_vide(coord_plateau, plateau)) {
    return 0;
  }
  if (!regle_forme_couleur(coord_plateau, piece, plateau)) {
    return 0;
  }
  if (!regle_pieces_jouees_alignees(coord_plateau, plateau, nb_pieces_jouees,
                                    pos_jouees)) {
    return 0;
  }
  return 1;
}
