#include "qwirkle.h"
#include "qwirkle_gui.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <math.h>
#include <stdio.h>
#include <time.h>

#ifndef M_PI
#define M_PI 3.14156
#endif

SDL_Window *win = NULL;
SDL_Renderer *ren = NULL;
TTF_Font *font = NULL;

char *f_image[NUM_COULEUR][NUM_FORME] = {
    {(char *)0, (char *)0, (char *)0, (char *)0, (char *)0},
    {"images/CarreRouge.bmp", "images/LozangeRouge.bmp",
     "images/TriangleRouge.bmp", "images/RondRouge.bmp",
     "images/FleurRouge.bmp", "images/EtoileRouge.bmp"},
    {"images/CarreVert.bmp", "images/LozangeVert.bmp",
     "images/TriangleVert.bmp", "images/RondVert.bmp", "images/FleurVert.bmp",
     "images/EtoileVert.bmp"},
    {"images/CarreJaune.bmp", "images/LozangeJaune.bmp",
     "images/TriangleJaune.bmp", "images/RondJaune.bmp",
     "images/FleurJaune.bmp", "images/EtoileJaune.bmp"},
    {"images/CarreMauve.bmp", "images/LozangeMauve.bmp",
     "images/TriangleMauve.bmp", "images/RondMauve.bmp",
     "images/FleurMauve.bmp", "images/EtoileMauve.bmp"},
    {"images/CarreOrange.bmp", "images/LozangeOrange.bmp",
     "images/TriangleOrange.bmp", "images/RondOrange.bmp",
     "images/FleurOrange.bmp", "images/EtoileOrange.bmp"},
    {"images/CarreBleu.bmp", "images/LozangeBleu.bmp",
     "images/TriangleBleu.bmp", "images/RondBleu.bmp", "images/FleurBleu.bmp",
     "images/EtoileBleu.bmp"},
};
SDL_Surface *images[NUM_COULEUR][NUM_FORME];
SDL_Texture *t_images[NUM_COULEUR][NUM_FORME];

int w_largeur = 640;
int w_hauteur = 480;

enum Etat_gui {
  ChoixNbreJoueur,
  ChoixIASud,
  ChoixIANord,
  ChoixIAEst,
  ChoixIAOuest,
  Selection_piece,
  Deplacement_piece,
  FinPartie,
} etat_gui;

typedef struct {
  Case piece_courante;
  int index_piece_courante;
  int x;
  int y;
  int pioche_ou_pose;
  SDL_Rect position_main[6];
  SDL_Rect fintour;
  SDL_Rect recommencertour;
  SDL_Rect nouvellepartie;
  SDL_Rect pioche;
  int piece_affiche[6];
} Gui;

Gui gui;

typedef enum {
  ModeJ2 = 0,
  ModeJ3,
  ModeJ4,
  VictoireSud,
  VictoireNord,
  VictoireOuest,
  VictoireEst,
  JoueSud,
  JoueNord,
  JoueOuest,
  JoueEst,
  LaPioche,
  FinTour,
  RecommencerTour,
  NouvellePartie,
  IASud,
  IANord,
  IAOuest,
  IAEst,
  Oui,
  Non,
  ScoreSud,
  ScoreNord,
  ScoreOuest,
  ScoreEst,
  Quit,
  Error,
  FinMessage
} MessagesGui;

SDL_Surface *surfaceMessages[FinMessage];
SDL_Color texte_color = {0, 0, 0, 255};

int reset_gui() { // fonction permettant de rénitialiser les elements du gui qui
                  // le necessitent a la fin de chaque tour
  etat_gui = ChoixNbreJoueur;
  gui.piece_courante.couleur = Vide;
  for (int i = 0; i < 6; ++i) {
    gui.piece_affiche[i] = 1;
  }
  gui.pioche_ou_pose = 0;
  // gui.nb_pions_joue = 0;
  return 0;
}

int init_gui() { // fonction d'initialisation du gui
  win = NULL;
  ren = NULL;
  font = NULL;
  for (int i = 0; i < 6; ++i) {
    for (int j = 0; j < 6; ++j) {
      t_images[i][j] = NULL;
      images[i][j] = NULL;
    }
  }
  if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    printf("SDL_Init Error: %s\n", SDL_GetError());
    return 1;
  }
  if (TTF_Init() != 0) {
    printf("TTF_Init erreur %s\n", TTF_GetError());
    SDL_Quit();
    return 0;
  }
  font = TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSans.ttf", 20);
  if (font == NULL) {
    printf("TTF_OpenFont erreur %s\n", TTF_GetError());
    font = TTF_OpenFont("font/FreeSans.ttf", 25);
  }
  if (font == NULL) {
    printf("TTF_OpenFont erreur %s\n", TTF_GetError());
    TTF_Quit();
    SDL_Quit();
    return 0;
  }
  surfaceMessages[ModeJ2] =
      TTF_RenderText_Blended(font, "Mode 2 joueurs", texte_color);
  surfaceMessages[ModeJ3] =
      TTF_RenderText_Blended(font, "Mode 3 joueurs", texte_color);
  surfaceMessages[ModeJ4] =
      TTF_RenderText_Blended(font, "Mode 4 joueurs", texte_color);
  surfaceMessages[VictoireSud] =
      TTF_RenderText_Blended(font, "Victoire Sud", texte_color);
  surfaceMessages[VictoireNord] =
      TTF_RenderText_Blended(font, "Victoire Nord", texte_color);
  surfaceMessages[VictoireOuest] =
      TTF_RenderText_Blended(font, "Victoire Ouest", texte_color);
  surfaceMessages[VictoireEst] =
      TTF_RenderText_Blended(font, "Victoire Est", texte_color);
  surfaceMessages[LaPioche] =
      TTF_RenderText_Blended(font, "Pioche", texte_color);
  surfaceMessages[JoueSud] =
      TTF_RenderText_Blended(font, "Joueur Sud", texte_color);
  surfaceMessages[JoueNord] =
      TTF_RenderText_Blended(font, "Joueur Nord", texte_color);
  surfaceMessages[JoueOuest] =
      TTF_RenderText_Blended(font, "Joueur Ouest", texte_color);
  surfaceMessages[JoueEst] =
      TTF_RenderText_Blended(font, "Joueur Est", texte_color);
  surfaceMessages[FinTour] =
      TTF_RenderText_Blended(font, "Fin du tour", texte_color);
  surfaceMessages[NouvellePartie] =
      TTF_RenderText_Blended(font, "Nouvelle Partie", texte_color);
  surfaceMessages[RecommencerTour] =
      TTF_RenderText_Blended(font, "Recommencer", texte_color);
  surfaceMessages[Quit] = TTF_RenderText_Blended(font, "Quitter", texte_color);
  surfaceMessages[IASud] = TTF_RenderText_Blended(font, "IASud", texte_color);
  surfaceMessages[IANord] = TTF_RenderText_Blended(font, "IANord", texte_color);
  surfaceMessages[IAOuest] =
      TTF_RenderText_Blended(font, "IAOuest", texte_color);
  surfaceMessages[IAEst] = TTF_RenderText_Blended(font, "IAEst", texte_color);
  surfaceMessages[Oui] = TTF_RenderText_Blended(font, "Oui", texte_color);
  surfaceMessages[Non] = TTF_RenderText_Blended(font, "Non", texte_color);
  surfaceMessages[Error] = TTF_RenderText_Blended(font, "Error", texte_color);
  win = SDL_CreateWindow("Hello World!", 100, 100, 640, 480, SDL_WINDOW_SHOWN);
  if (win == NULL) {
    printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
    return 1;
  }
  ren = SDL_CreateRenderer(
      win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (ren == NULL) {

    printf("SDL_CreateRenderer Error: %s", SDL_GetError());

    return 1;
  }
  for (int i = 0; i < NUM_COULEUR; ++i) {
    for (int j = 0; j < NUM_FORME; ++j) {
      if (f_image[i][j] == NULL)
        continue;
      images[i][j] = SDL_LoadBMP(f_image[i][j]);
      if (images[i][j] == NULL) {
        printf("Erreur lecture %s\n", f_image[i][j]);
        return 1;
      }
      t_images[i][j] = SDL_CreateTextureFromSurface(ren, images[i][j]);
      if (t_images[i][j] == NULL) {
        return 1;
      }
    }
  }
  reset_gui();
  return 0;
}

float taille_cote(
    Plateau *plateau) { // fonction calculant la taille des cases du plateau
  float cote = (float)(w_hauteur > w_largeur ? w_largeur : w_hauteur) /
               plateau->dimension_plateau_jeu.nb_colonnes;
  return cote;
}

void affiche_imgage( // fonction d'affichage des images des différentes pieces
    Case *piece, SDL_Rect rect) {
  SDL_RenderCopy(ren, t_images[piece->couleur][piece->forme], NULL, &rect);
}

void render_main(Partie *partie, int x,
                 int y) { // fonction d'affichage de la main du joueur
  Case piece;
  Jeu *cur_jeu = main_courante(partie);
  for (int i = 0; i < 6; ++i) {
    gui.position_main[i].w = 25;
    gui.position_main[i].h = 25;
    piece.couleur = cur_jeu->jeu[i].couleur;
    piece.forme = cur_jeu->jeu[i].forme;
    gui.position_main[i].x = x + i * 25;
    gui.position_main[i].y = y;
    if (gui.piece_affiche[i] == 1) {
      affiche_imgage(&piece, gui.position_main[i]);
    }
  }
}

SDL_Rect print_message(MessagesGui m, int x, int y,
                       char button) { // fonction d'affichages des messages
  SDL_Texture *Message = SDL_CreateTextureFromSurface(
      ren, surfaceMessages[m]); // sert à convertir le message en texture
  SDL_Rect Message_rect;
  Message_rect.x = x;
  Message_rect.y = y;
  Message_rect.w = surfaceMessages[m]->w + 4;
  Message_rect.h = surfaceMessages[m]->h + 4;
  SDL_SetRenderDrawColor(ren, 100, 100, 100, 255);
  SDL_RenderFillRect(ren, &Message_rect);
  SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
  if (button)
    SDL_RenderDrawRect(ren, &Message_rect);
  SDL_Rect cadre;
  cadre.x = x + 2;
  cadre.y = y + 2;
  cadre.w = surfaceMessages[m]->w;
  cadre.h = surfaceMessages[m]->h;
  SDL_RenderCopy(ren, Message, NULL, &cadre);
  // SDL_FreeSurface(surfaceMessage);
  SDL_DestroyTexture(Message);

  return Message_rect;
}

SDL_Rect print_score(char *txt, int score, int x, int y,
                     char button) { // fonction d'affichage des scores
  SDL_Surface *surface;
  SDL_Texture *texture;
  char buf[50];
  sprintf(buf, "%s: %d", txt, score);
  surface = TTF_RenderText_Blended(font, buf, texte_color);
  texture = SDL_CreateTextureFromSurface(ren, surface);
  SDL_Rect Score_rect;
  Score_rect.x = x;
  Score_rect.y = y;
  Score_rect.w = surface->w + 4;
  Score_rect.h = surface->h + 4;
  SDL_SetRenderDrawColor(ren, 100, 100, 100, 255);
  SDL_RenderFillRect(ren, &Score_rect);
  SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
  if (button)
    SDL_RenderDrawRect(ren, &Score_rect);
  SDL_Rect cadre;
  cadre.x = x + 2;
  cadre.y = y + 2;
  cadre.w = surface->w;
  cadre.h = surface->h;
  SDL_RenderCopy(ren, texture, NULL, &cadre);
  SDL_DestroyTexture(texture);

  return Score_rect;
}

void print_scores(int x, int y,
                  Partie *partie) { // fonction appellant l'affichage des scores
  print_score("Sud", partie->joueur.score_sud, x, y, 0);
  print_score("Nord", partie->joueur.score_nord, x, y + 32, 0);
  print_score("Ouest", partie->joueur.score_ouest, x, y + 64, 0);
  print_score("Est", partie->joueur.score_est, x, y + 96, 0);
}

void render_texte(Partie *partie) { // fonction appelant l'affichage de tous les
                                    // messages visible en cour de jeu
  MessagesGui mjoueur = JoueSud;
  switch (partie->joueur.position) {
  case Sud:
    mjoueur = JoueSud;
    break;
  case Nord:
    mjoueur = JoueNord;
    break;
  case Ouest:
    mjoueur = JoueOuest;
    break;
  case Est:
    mjoueur = JoueEst;
    break;
  default:
    mjoueur = JoueSud;
    break;
  }
  int base_x = 483;
  int base_y = 10;
  int inter_ligne = 5;
  SDL_Rect rect_m = print_message(mjoueur, base_x, base_y, 0);
  base_y += rect_m.h + inter_ligne;
  render_main(partie, base_x, base_y);
  base_y += gui.pioche.h + inter_ligne;
  gui.pioche = print_message(LaPioche, base_x, base_y, 1);
  base_y += gui.position_main[0].h + inter_ligne;
  gui.recommencertour = print_message(RecommencerTour, base_x, base_y, 1);
  base_y += gui.recommencertour.h + inter_ligne;
  gui.fintour = print_message(FinTour, base_x, base_y, 1);
  base_y += gui.fintour.h + inter_ligne;
  gui.nouvellepartie = print_message(NouvellePartie, base_x, base_y, 1);
  base_y += gui.nouvellepartie.h + inter_ligne;
  print_scores(base_x, base_y, partie);
}

void render_plateau_gui(Partie *partie) { // fonction d'affichage du plateau
  Dimension dimension;
  dimension = dimension_affichage_plateau(partie);
  int i;
  float cote = taille_cote(&partie->plateau);
  int total_larg = cote * dimension.nb_colonnes;
  for (i = 0; i < dimension.nb_colonnes + 1; ++i) {
    SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
    SDL_RenderDrawLine(ren, cote * i, 0, cote * i, 480);
  }
  for (i = 0; i < dimension.nb_rangees + 1; ++i) {
    SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
    SDL_RenderDrawLine(ren, 0, cote * i, total_larg, cote * i);
  }
  for (int i = 0; i < dimension.nb_colonnes; ++i) {
    for (int j = 0; j < dimension.nb_rangees; ++j) {
      Case piece = get_cases(&partie->plateau, i, j);
      if (piece.couleur != Vide) {
        SDL_Rect rect;
        rect.x = cote * i;
        rect.y = cote * j;
        rect.w = cote;
        rect.h = cote;
        affiche_imgage(&piece, rect);
        // printf("%d %d %s\n", i, j, f_image[piece.couleur][piece.forme]);
      }
    }
  }
}

void affichge_gui(Partie *partie) { // fonction pour l'affichage general
  render_plateau_gui(partie);
  render_texte(partie);
}

void recommencer_tour(Partie *partie,
                      Gui *gui) { // fonction permettant au joueur de
                                  // recommencer son tour s'il s'est trompé
  for (int i = 0; i < partie->nb_pieces_jouees; ++i) {
    partie->plateau.cases[partie->pos_jouees[i].y][partie->pos_jouees[i].x]
        .couleur = Vide;
  }
  for (int i = 0; i < 6; ++i) {
    gui->piece_affiche[i] = 1;
    partie->depotpioche[i].couleur = Vide;
  }
  partie->nb_pieces_jouees = 0;
  if (partie->tour == 1) {
    partie->premier_pion = 1;
  }
  gui->pioche_ou_pose = 0;
}

void fin_tour(Partie *partie,
              Gui *gui) { // fonction appelant les differentes fonction
                          // necessaire a la fin du tour (calcul du score...)

  partie_fin_tour(partie, gui->piece_affiche);
  gui->pioche_ou_pose = 0;
}

int cliquer_dans_la_main(
    Partie *partie) { // fonction de selection de l'action choisie par le joueur
                      // pour son tour (jouer ou piocher)
  // printf("choisir une piece\n");
  affichge_gui(partie);
  // SDL_RenderPresent(ren);

  SDL_Event e;
  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_QUIT) {
      return 1;
    }

    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;

      for (int i = 0; i < 6; ++i) {
        if (SDL_PointInRect(&point, &gui.position_main[i])) {

          if (gui.piece_affiche[i] == 1) {
            etat_gui = Deplacement_piece;
            // printf("la piece choisitest la n %d\n", p);
            Case piece = get_piece_main(i, partie);
            gui.piece_courante = piece;
            gui.index_piece_courante = i;
            gui.piece_affiche[i] = 0;
          } else {
            gui.piece_courante.couleur = Vide;
          }

          break;
        }
      }
      if (SDL_PointInRect(&point, &gui.fintour)) {
        if (partie->premier_pion == 1) {
          break;
        } else if ((partie->tour == 1) &&
                   (partie->nb_pieces_jouees < partie->nb_piece_premier_tour)) {
          break;
        } else if (gui.pioche_ou_pose != 0) {
          fin_tour(partie, &gui);
          if (partie->pioche.nombre_de_pions != 0) {
            etat_gui = Selection_piece;
          }
          break;
        }

      } else if (SDL_PointInRect(&point, &gui.nouvellepartie)) {
        reset_gui();
        etat_gui = ChoixNbreJoueur;
        break;
      } else if (SDL_PointInRect(&point, &gui.recommencertour)) {
        recommencer_tour(partie, &gui);
        break;
      }
    }
  }
  return 0;
}

int deplacement_piece_gui(
    Partie *partie,
    Gui *gui) { // fonction permettant de bouger la piece selectionee vers le
                // plateau de jeu ou la pioche
  SDL_Rect rect;
  int x, y;
  float cote = taille_cote(&partie->plateau);
  rect.h = cote;
  rect.w = cote;
  affichge_gui(partie);

  SDL_Event e;
  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_QUIT) {
      return 1;
    }
    SDL_GetMouseState(&rect.x, &rect.y);
    rect.x -= rect.h / 2;
    rect.y -= rect.w / 2;
    affiche_imgage(&gui->piece_courante, rect);
    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;
      if (SDL_PointInRect(&point, &gui->pioche)) {
        if ((gui->pioche_ou_pose == 0) || (gui->pioche_ou_pose == 1)) {
          if (partie->premier_pion != 1) {
            partie->depotpioche[partie->cur_pioche] = gui->piece_courante;
            gui->piece_courante.couleur = Vide;
            ++partie->cur_pioche;
            gui->pioche_ou_pose = 1;
            etat_gui = Selection_piece;
          }
        }
      }
      x = e.button.x / cote;
      y = e.button.y / cote;
      if (x < partie->plateau.dimension_plateau_jeu.nb_colonnes &&
          y < partie->plateau.dimension_plateau_jeu.nb_rangees) {
        if (partie->premier_pion == 1) {
          Coord centre = {88, 88};
          rempli_case(partie, centre, gui->piece_courante);
          etat_gui = Selection_piece;
          gui->pioche_ou_pose = 2;
          partie->premier_pion = 0;

        } else {
          if ((gui->pioche_ou_pose == 0) || (gui->pioche_ou_pose == 2)) {
            Coord coord_plateau = get_coord_plateau(&partie->plateau, x, y);

            if (regles(coord_plateau, gui->piece_courante, &partie->plateau,
                       partie->nb_pieces_jouees, partie->pos_jouees)) {

              rempli_case(partie, coord_plateau, gui->piece_courante);
              etat_gui = Selection_piece;
              gui->pioche_ou_pose = 2;
            } else {
              etat_gui = Selection_piece;
              gui->piece_affiche[gui->index_piece_courante] = 1;
            }
          }
        }
      }
    }
  }

  return 0;
}

char step_gui_choix_nbre_joueure(
    Partie *partie) { // fonction du debut de partie pour la selection du
                      // nombre de joueurs
  SDL_Event e;
  char quit = 0;
  SDL_Rect r1 = print_message(ModeJ2, 50, 200, 1);
  SDL_Rect r2 = print_message(ModeJ3, r1.x + r1.w + 10, 200, 1);
  SDL_Rect r3 = print_message(ModeJ4, r2.x + r2.w + 10, 200, 1);

  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {

    // If user closes the window
    if (e.type == SDL_QUIT) {
      quit = 1;
    }
    if (etat_gui == ChoixNbreJoueur) {
      if (e.type == SDL_MOUSEBUTTONDOWN) {
        SDL_Point point;
        point.x = e.button.x;
        point.y = e.button.y;
        if (SDL_PointInRect(&point, &r1)) {
          etat_gui = ChoixIASud;
          partie_init(partie, 2);
        } else if (SDL_PointInRect(&point, &r2)) {
          etat_gui = ChoixIASud;
          partie_init(partie, 3);
        } else if (SDL_PointInRect(&point, &r3)) {
          etat_gui = ChoixIASud;
          partie_init(partie, 4);
        }
      }
    }
  }

  return quit;
}

char step_gui_choix_ia(
    Partie *partie) { // fonction du debut de partie permettant de
                      // selectionner si un des joueurs sera jouer par une ia
  SDL_Event e;
  char quit = 0;
  MessagesGui m = Error;
  int nia = Sud;
  enum Etat_gui nextetat = Selection_piece;
  if (etat_gui == ChoixIASud) {
    m = IASud;
    nia = Sud;
    nextetat = ChoixIANord;
  } else if (etat_gui == ChoixIANord) {
    m = IANord;
    nia = Nord;
    if (partie->nombre_joueurs == 2) {
      nextetat = Selection_piece;
    } else {
      nextetat = ChoixIAOuest;
    }
  } else if (etat_gui == ChoixIAOuest) {
    nia = Ouest;
    m = IAOuest;
    if (partie->nombre_joueurs == 3) {
      nextetat = Selection_piece;
    } else {

      nextetat = ChoixIAEst;
    }
  } else if (etat_gui == ChoixIAEst) {
    nia = Est;

    m = IAEst;
    nextetat = Selection_piece;
  }
  print_message(m, 50, 100, 0);
  SDL_Rect r1 = print_message(Oui, 50, 200, 1);
  SDL_Rect r2 = print_message(Non, r1.x + r1.w + 10, 200, 1);
  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {

    // If user closes the window
    if (e.type == SDL_QUIT) {
      quit = 1;
    }
    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;
      if (SDL_PointInRect(&point, &r1)) {
        etat_gui = nextetat;
        partie->ia[nia] = 1;
      } else if (SDL_PointInRect(&point, &r2)) {

        etat_gui = nextetat;
        partie->ia[nia] = 0;
      }
    }
  }

  return quit;
}

char gui_fin_partie(Partie *partie) {
  SDL_Rect r1 = print_message(NouvellePartie, 200, 200, 1);
  SDL_Rect r2 = print_message(Quit, r1.x + r1.w + 10, 200, 1);
  MessagesGui m = VictoireSud;
  if (partie->joueur.score_est < partie->joueur.score_sud &&
      partie->joueur.score_nord < partie->joueur.score_sud &&
      partie->joueur.score_ouest < partie->joueur.score_sud)
    m = VictoireSud;
  if (partie->joueur.score_est < partie->joueur.score_nord &&
      partie->joueur.score_sud < partie->joueur.score_nord &&
      partie->joueur.score_ouest < partie->joueur.score_nord)
    m = VictoireNord;
  if (partie->joueur.score_est < partie->joueur.score_ouest &&
      partie->joueur.score_sud < partie->joueur.score_ouest &&
      partie->joueur.score_nord < partie->joueur.score_ouest)
    m = VictoireOuest;
  if (partie->joueur.score_nord < partie->joueur.score_est &&
      partie->joueur.score_sud < partie->joueur.score_est &&
      partie->joueur.score_ouest < partie->joueur.score_est)
    m = VictoireEst;
  print_message(m, 300, 100, 0);
  print_scores(480, 50, partie);

  SDL_Event e;
  char quit = 0;
  SDL_WaitEvent(NULL);
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_QUIT) {
      quit = 1;
    }
    if (e.type == SDL_MOUSEBUTTONDOWN) {
      SDL_Point point;
      point.x = e.button.x;
      point.y = e.button.y;
      if (SDL_PointInRect(&point, &r1)) {
        etat_gui = ChoixNbreJoueur;

      } else if (SDL_PointInRect(&point, &r2)) {
        quit = 1;
      }
    }
  }
  return quit;
}

void destroy_images() { // fonction permettant de suprimer les surfaces des
                        // images crees lorsque le programme se termine
  for (int i = 0; i < NUM_COULEUR; ++i) {
    for (int j = 0; j < NUM_FORME; ++j) {
      if (images[i][j] != NULL) {
        SDL_FreeSurface(images[i][j]);
        images[i][j] = NULL;
      }
    }
  }
}

void destroy_t_images() { // fonction permettant de suprimer les textures
                          // crees lorsque le programme se termine
  for (int i = 0; i < NUM_COULEUR; ++i) {
    for (int j = 0; j < NUM_FORME; ++j) {
      if (t_images[i][j] != NULL) {
        SDL_DestroyTexture(t_images[i][j]);
        t_images[i][j] = NULL;
      }
    }
  }
}

void free_tous_messages() { // fonction permettant de suprimer les surfaces des
                            // messages crees lorsque le programme se termine
  for (int i = 0; i < FinMessage; ++i) {
    SDL_FreeSurface(surfaceMessages[i]);
  }
}

char stop_gui() { // fonction mettant fin au fonctionnement du gui et liberant
                  // la memoire utilisee
  if (font != NULL) {
    TTF_CloseFont(font);
  }
  destroy_t_images();
  destroy_images();
  free_tous_messages();
  if (ren != NULL) {
    SDL_DestroyRenderer(ren);
    ren = NULL;
  }
  if (win != NULL) {
    SDL_DestroyWindow(win);
    win = NULL;
  }
  TTF_Quit();
  SDL_Quit();
  return 1;
}

int main() { // fonction principale appelant les fonctions necessaire au
             // fonctionnement du programme
  srand(time(NULL));
  Partie partie;
  partie_init(&partie, 2);
  if (init_gui() != 0) {
    stop_gui();
    return 1;
  }
  char quit = 0;
  while (!quit) {
    SDL_SetRenderDrawColor(ren, 0, 0, 0, 0);

    SDL_RenderClear(ren);

    // printf("Render\n");
    if (etat_gui == ChoixNbreJoueur) {
      quit = step_gui_choix_nbre_joueure(&partie);
    } else if (etat_gui == ChoixIASud || etat_gui == ChoixIANord ||
               etat_gui == ChoixIAEst || etat_gui == ChoixIAOuest) {
      quit = step_gui_choix_ia(&partie);
    } else if (etat_gui == Selection_piece) {
      if (partie.ia[partie.joueur.position]) {
        ai_joue(&partie);
        gui.pioche_ou_pose = 0;
        affichge_gui(&partie);

      } else {
        quit = cliquer_dans_la_main(&partie);
      }
      if (partie_finie(&partie)) {
        etat_gui = FinPartie;
      }

    } else if (etat_gui == Deplacement_piece) {
      quit = deplacement_piece_gui(&partie, &gui);
    } else if (etat_gui == FinPartie) {
      quit = gui_fin_partie(&partie);
    }
    SDL_RenderPresent(ren);
  }
  stop_gui();
  return 0;
}
