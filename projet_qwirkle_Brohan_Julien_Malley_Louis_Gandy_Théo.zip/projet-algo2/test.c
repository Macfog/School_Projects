#include "qwirkle.h"
#include <stdio.h>

// test verif si une case est vide

void test_case_vide(void) {
  int x, y;
  Coord coord;
  Partie partie;
  Case piece = {Jaune, Rond};

  init_plateau(&partie);
  coord.x = 5;
  coord.y = 9;
  rempli_case_plateau(&partie.plateau, coord, piece);

  coord.x = 25;
  coord.y = 25;
  rempli_case_plateau(&partie.plateau, coord, piece);

  coord.x = 39;
  coord.y = 20;
  rempli_case_plateau(&partie.plateau, coord, piece);

  for (x = 0; x >= 50; ++x) {
    coord.x = x;
    for (y = 0; y >= 50; ++y) {
      coord.y = y;
      if (verif_case_vide(coord, &partie.plateau) != 1) {
        if ((coord.x == 5 && coord.y == 9) ||
            (coord.x == 25 && coord.y == 25) ||
            (coord.x == 39 && coord.y == 20)) {
        } else {
          printf("ERREUR, case vide considérée non vide\n");
        }
      }
    }
  }
}

void test_case_adj_non_vide(void) {
  int tmp;
  Coord A, B, C, D;
  Partie partie;
  init_plateau(&partie);
  Case piece = {Jaune, Rond};
  Coord pos = {2, 10};
  rempli_case_plateau(&partie.plateau, pos, piece);
  A.x = 1;
  A.y = 10;
  B.x = 1;
  B.y = 3;
  C.x = 2;
  C.y = 9;
  D.x = 2;
  D.y = 11;
  tmp = verif_case_adjacente_non_vide(A, &partie.plateau);
  if (tmp == 0) {
    printf("ERREUR test_case_adj_non_vide pour coord A\n");
  }
  tmp = verif_case_adjacente_non_vide(B, &partie.plateau);
  if (tmp == 1) {
    printf("ERREUR test_case_adj_non_vide pour coord B\n");
  }
  tmp = verif_case_adjacente_non_vide(C, &partie.plateau);
  if (tmp == 0) {
    printf("ERREUR test_case_adj_non_vide pour coord C\n");
  }
  tmp = verif_case_adjacente_non_vide(D, &partie.plateau);
  if (tmp == 0) {
    printf("ERREUR test_case_adj_non_vide pour coord D\n");
  }
}

void test_attribut_commun_ligneG(void) {
  int tmp;
  Plateau plateau;
  Coord coord;
  Partie partie;
  Case piece;
  init_plateau(&partie);
  coord.x = 3;
  coord.y = 10;
  piece.couleur = Rouge;
  piece.forme = Carre;
  plateau.cases[2][10].couleur = Rouge;
  plateau.cases[2][10].forme = Rond;
  plateau.cases[1][10].couleur = Rouge;
  plateau.cases[1][10].forme = Etoile;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun ligne gauche non détecté");
  }

  coord.x = 7;
  coord.y = 5;
  piece.couleur = Rouge;
  piece.forme = Fleur;
  plateau.cases[6][5].couleur = Vert;
  plateau.cases[6][5].forme = Carre;
  plateau.cases[5][5].couleur = Jaune;
  plateau.cases[5][5].forme = Lozange;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun ligne gauche 2 ");
  }
}

void test_attribut_commun_ligneD(void) {
  int tmp;
  Plateau plateau;
  Coord coord;
  Partie partie;
  Case piece;
  init_plateau(&partie);
  coord.x = 1;
  coord.y = 10;
  piece.couleur = Rouge;
  piece.forme = Carre;
  plateau.cases[2][10].couleur = Rouge;
  plateau.cases[2][10].forme = Rond;
  plateau.cases[3][10].couleur = Rouge;
  plateau.cases[3][10].forme = Etoile;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun ligne droite non détecté");
  }

  coord.x = 5;
  coord.y = 5;
  piece.couleur = Rouge;
  piece.forme = Fleur;
  plateau.cases[6][5].couleur = Vert;
  plateau.cases[6][5].forme = Carre;
  plateau.cases[7][5].couleur = Jaune;
  plateau.cases[7][5].forme = Lozange;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun ligne droite 2 ");
  }
}

void test_attribut_commun_ColonneH(void) {
  int tmp;
  Plateau plateau;
  Coord coord;
  Partie partie;
  Case piece;
  init_plateau(&partie);
  coord.x = 1;
  coord.y = 10;
  piece.couleur = Rouge;
  piece.forme = Carre;
  plateau.cases[1][9].couleur = Rouge;
  plateau.cases[1][9].forme = Rond;
  plateau.cases[1][8].couleur = Rouge;
  plateau.cases[1][8].forme = Etoile;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun colonne haut non détecté");
  }

  coord.x = 7;
  coord.y = 5;
  piece.couleur = Rouge;
  piece.forme = Fleur;
  plateau.cases[7][4].couleur = Vert;
  plateau.cases[7][4].forme = Carre;
  plateau.cases[7][3].couleur = Jaune;
  plateau.cases[7][3].forme = Lozange;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun colonne haut 2 ");
  }
}

void test_attribut_commun_ColonneB(void) {
  int tmp;
  Plateau plateau;
  Coord coord;
  Partie partie;
  Case piece;
  init_plateau(&partie);
  coord.x = 1;
  coord.y = 10;
  piece.couleur = Rouge;
  piece.forme = Carre;
  plateau.cases[1][11].couleur = Rouge;
  plateau.cases[1][11].forme = Rond;
  plateau.cases[1][12].couleur = Rouge;
  plateau.cases[1][12].forme = Etoile;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun colonne bas non détecté");
  }

  coord.x = 7;
  coord.y = 5;
  piece.couleur = Rouge;
  piece.forme = Fleur;
  plateau.cases[7][6].couleur = Vert;
  plateau.cases[7][6].forme = Carre;
  plateau.cases[7][7].couleur = Jaune;
  plateau.cases[7][7].forme = Lozange;
  tmp = regle_forme_couleur(coord, piece, &plateau);
  if (tmp == 0) {
    printf("ERREUR attribut commun colonne bas 2 ");
  }
}
int main(void) {
  test_case_vide();
  test_case_adj_non_vide();
  test_attribut_commun_ligneG();
  return 0;
}