#include "qwirkle.h"
#include <stdio.h>

typedef struct {
  Coord pos_jouee[6];
  Case piece[6];
  int idx_piece_main_jouees[6];
  int nb_pos_jouees;
} MeilleursCoups;

void ai_joue_coup_intermediaire(Plateau *plateau_tmp, Jeu *main_joueur,
                                int piece_main_dispo[6],
                                MeilleursCoups *candidat, int *meilleur_score,
                                MeilleursCoups *meilleur, int tour) {
  for (int y = 1; y < SZ_PLATEAU - 1; ++y) {
    for (int x = 1; x < SZ_PLATEAU - 1; ++x) {
      Coord coord_plateau = {x, y};
      if (verif_case_adjacente_non_vide(coord_plateau, plateau_tmp) &&
          verif_case_vide(coord_plateau, plateau_tmp)) {
        for (int idx_p = 0; idx_p < 6; ++idx_p) {
          if (piece_main_dispo[idx_p] == 0)
            continue;
          Case piece = main_joueur->jeu[idx_p];
          if (piece.couleur == Vide) {
            // pioche vide toutes les pieces ne sont pas dispo
            continue;
          }
          if (regles(coord_plateau, piece, plateau_tmp, candidat->nb_pos_jouees,
                     candidat->pos_jouee)) {
            candidat->pos_jouee[candidat->nb_pos_jouees] = coord_plateau;
            candidat->idx_piece_main_jouees[candidat->nb_pos_jouees] = idx_p;
            candidat->piece[candidat->nb_pos_jouees] = piece;
            piece_main_dispo[idx_p] = 0;

            ++candidat->nb_pos_jouees;
            rempli_case_plateau(plateau_tmp, coord_plateau, piece);

            int score = calcul_score(plateau_tmp, candidat->nb_pos_jouees,
                                     candidat->pos_jouee, tour);

            if (*meilleur_score < score) {
              *meilleur_score = score;
              meilleur->nb_pos_jouees = candidat->nb_pos_jouees;
              for (int i = 0; i < candidat->nb_pos_jouees; ++i) {
                meilleur->idx_piece_main_jouees[i] =
                    candidat->idx_piece_main_jouees[i];
                meilleur->pos_jouee[i] = candidat->pos_jouee[i];
                meilleur->piece[i] = candidat->piece[i];
              }
            }
            ai_joue_coup_intermediaire(plateau_tmp, main_joueur,
                                       piece_main_dispo, candidat,
                                       meilleur_score, meilleur, tour);

            Case vide = {Vide, Rond};
            rempli_case_plateau(plateau_tmp, coord_plateau, vide);
            --candidat->nb_pos_jouees;
            piece_main_dispo[idx_p] = 1;
          }
        }
      }
    }
  }
  return;
}

int ai_joue(Partie *partie) {

  // printf("ai\n");

  MeilleursCoups meilleur;
  meilleur.nb_pos_jouees = 0;
  int meilleur_score = 0;
  MeilleursCoups candidat;
  candidat.nb_pos_jouees = 0;
  Plateau plateau_tmp;
  copie_plateau(&partie->plateau, &plateau_tmp);
  Jeu *main_joueur = main_courante(partie);
  int piece_main_dispo[6];
  for (int i = 0; i < 6; ++i) {
    piece_main_dispo[i] = 1;
  }
  if (partie->tour == 1) {
    int t_couleur[6];
    int t_forme[6];
    int t_piece_unique[6 * 6];
    for (int j = 0; j < 6 * 6; ++j) {
      t_piece_unique[j] = 0;
    }
    for (int j = 0; j < 6; ++j) {
      t_couleur[j] = 0;
      t_forme[j] = 0;
    }
    for (int j = 0; j < 6; ++j) {
      if (t_piece_unique[main_joueur->jeu[j].forme * 6 +
                         main_joueur->jeu[j].couleur - 1] != 0)
        continue;
      t_piece_unique[main_joueur->jeu[j].forme * 6 +
                     main_joueur->jeu[j].couleur - 1] = 1;
      ++t_couleur[main_joueur->jeu[j].couleur - 1];
      ++t_forme[main_joueur->jeu[j].forme];
    }
    int max_couleur = 0;
    Couleur meilleur_couleur = 0;
    int max_forme = 0;
    Forme meilleur_forme = 0;
    for (int j = 0; j < 6; ++j) {
      if (t_couleur[j] > max_couleur) {
        max_couleur = t_couleur[j];
        meilleur_couleur = j + 1;
      }
      if (t_forme[j] > max_forme) {
        max_forme = t_forme[j];
        meilleur_forme = j;
      }
    }
    for (int j = 0; j < 6 * 6; ++j) {
      t_piece_unique[j] = 0;
    }
    if (max_couleur > max_forme) {
      int npiece = 0;
      for (int j = 0; j < 6; ++j) {
        if (t_piece_unique[main_joueur->jeu[j].forme * 6 +
                           main_joueur->jeu[j].couleur - 1] != 0)
          continue;
        if ((main_joueur->jeu[j].couleur) == meilleur_couleur) {
          Coord coord_plateau = {88 + npiece, 88};
          rempli_case_plateau(&partie->plateau, coord_plateau,
                              main_joueur->jeu[j]);
          piece_main_dispo[j] = 0;
          ++npiece;
        }
      }
    } else {
      int npiece = 0;
      for (int j = 0; j < 6; ++j) {
        if (t_piece_unique[main_joueur->jeu[j].forme * 6 +
                           main_joueur->jeu[j].couleur - 1] != 0)
          continue;
        if (main_joueur->jeu[j].forme == meilleur_forme) {
          Coord coord_plateau = {88 + npiece, 88};
          rempli_case(partie, coord_plateau, main_joueur->jeu[j]);
          piece_main_dispo[j] = 0;
          ++npiece;
        }
      }
    }
    partie->premier_pion = 0;
    partie_fin_tour(partie, piece_main_dispo);

  } else {
    ai_joue_coup_intermediaire(&plateau_tmp, main_joueur, piece_main_dispo,
                               &candidat, &meilleur_score, &meilleur,
                               partie->tour);

    if (meilleur_score > 0) {
      for (int i = 0; i < meilleur.nb_pos_jouees; ++i) {
        rempli_case(partie, meilleur.pos_jouee[i], meilleur.piece[i]);
        piece_main_dispo[meilleur.idx_piece_main_jouees[i]] = 0;
      }
      partie_fin_tour(partie, piece_main_dispo);

    } else {
      for (int i = 0; i < 6; ++i) {
        if (piece_main_dispo[i] == 0)
          continue;
        partie->depotpioche[partie->cur_pioche] = main_joueur->jeu[i];
        piece_main_dispo[i] = 0;
        ++partie->cur_pioche;
      }
      partie_fin_tour(partie, piece_main_dispo);
    }
  }
  return 1;
}