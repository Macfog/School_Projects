# README #

Pour pouvoir jouer au jeu, il faut les bibliothèques : SDL2/SDL.h, SDL2/SDL_image.h, SDL2/SDL_ttf.h, math.h, stdio.h et time.h

Pour compiler, il faut entrer 'make' dans le terminal. Un executable nommé qwirkle sera crée.
Pour lancer le jeu, il faut utiliser la commande ./qwirkle.

Le jeu peut être jouer de 2 à 4 joueurs. Le programme demandera la présence ou non d'ia .

Le joueur qui joue en premier, et celui qui a le plus de pions possédant au moins un attribut en commun.

Pour poser un pion, il faut faire un clic gauche sur le pion puis
un clic gauche sur la case ou on veu poser le pion.
Les pions joués durant le même tour doivent tous être posé sur la même ligne.

Lorsque le joueur pose un pion, si le coup est invalide, le pion retournera directement dans la main du joueur.

Pour échanger un ou plusieurs pions, il faut cliquer sur le pion puis sur le bouton pioche.

Pour mettre fin a un tour de jeu, il suffit de cliquer sur le bouton fin de tour.

Le bouton recommencer permet au joueur d'annuler les actions de son tour et de recommencer son tour.

Le bouton nouvelle partie permet de mettre fin à la partie en cours et d'en commencer une nouvelle.