#ifndef __QWIRKLE_H__
#define __QWIRKLE_H__

#include <stdio.h>
#include <stdlib.h>

/*Creation des différents types de cases et pions possibles*/
typedef enum {
  Vide,
  Rouge,
  Vert,
  Jaune,
  Mauve,
  Bleu,
  Orange,
  NUM_COULEUR,
} Couleur;

typedef enum {
  Carre,
  Lozange,
  Triangle,
  Rond,
  Fleur,
  Etoile,
  NUM_FORME,
} Forme;

typedef struct {
  Couleur couleur;
  Forme forme;
} Case;

typedef struct {
  int x;
  int y;
} Coord;

typedef struct {
  int nb_colonnes;
  int nb_rangees;
  Coord a;
} Dimension;

// creation d'une structure joueur avec une position et un jeu
typedef struct {
  Case jeu[6];
} Jeu;

typedef enum { Nord, Sud, Ouest, Est } Position;

typedef struct {
  Jeu jeu_nord;
  Jeu jeu_sud;
  Jeu jeu_ouest;
  Jeu jeu_est;
  Position position;
  int score_sud;
  int score_nord;
  int score_ouest;
  int score_est;
} Joueur;

#define SZ_PLATEAU 184

typedef struct {
  Case cases[SZ_PLATEAU][SZ_PLATEAU];
  Dimension dimension_plateau_jeu;
} Plateau;

typedef struct {
  Case pions_pioche[108];
  int nombre_de_pions;
} Pioche;

/*Creation d'une structure partie nous permettant
d'avoir accès plus facilement aux autres structures*/
typedef struct {
  int nombre_joueurs;
  int nb_piece_premier_tour;
  Plateau plateau;
  int tour;
  Joueur joueur;
  Pioche pioche;
  char ia[4];
  int premier_pion;
  int nb_pieces_jouees;
  Coord pos_jouees[6];
  Case depotpioche[6];
  int cur_pioche;

} Partie;

void init_plateau(Partie *partie);
void init_pioche(Partie *partie);
Case pioche_piece(Partie *partie);
void remet_pioche_piece(Partie *partie, Case piece);
void init_main_jeu(Partie *partie);
void init_score(Partie *partie);
void init_nombre_de_joueur(Partie *partie, int x);
void partie_init(Partie *partie, int nb_joueur);
void copie_plateau(Plateau *orig, Plateau *dest);
void partie_fin_tour(Partie *partie, int piece_dispo[6]);
int partie_finie(Partie *partie);

Case get_piece_main(int p, Partie *partie);
void rempli_case_plateau(Plateau *plateau, Coord coord_plateau, Case piece);
void rempli_case(Partie *partie, Coord coord_plateau, Case piece);
Case get_cases_coord_plateau(Plateau *plateau, int x, int y);

Position joueur_suivant(Partie *partie);

Dimension dimension_affichage_plateau(Partie *partie);

int calcul_score(Plateau *plateau, int nb_pieces_jouees, Coord *pos_jouees,
                 int tour);

Coord get_coord_plateau(Plateau *plateau, int x, int y);
Case get_cases(Plateau *plateau, int x, int y);
void set_cases(Plateau *plateau, int x, int y, Case piece);

Position premier_joueur(Partie *partie);
int verif_case_vide(Coord coord_plateau, Plateau *plateau);
int verif_case_adjacente_non_vide(Coord coord_plateau, Plateau *plateau);
int regle_forme_couleur(Coord coord_plateau, Case piece, Plateau *plateau);
int regle_pieces_jouees_alignees(Coord coord_plateau, Plateau *plateau,
                                 int nb_pieces_jouees, Coord *pos_jouees);
int regles(Coord coord_plateau, Case piece, Plateau *plateau,
           int nb_pieces_jouees, Coord *pos_jouees);

Jeu *main_courante(Partie *partie);

int ai_joue(Partie *partie);

#endif
