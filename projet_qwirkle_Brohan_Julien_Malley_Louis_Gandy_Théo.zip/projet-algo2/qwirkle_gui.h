#ifndef __QWIRKLE_GUI_H__
#define __QWIRKLE_GUI_H__

#include "qwirkle.h"

int init_gui();
char stop_gui();

#endif