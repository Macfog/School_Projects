#include "qwirkle.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void init_plateau(Partie *partie) {
  for (int i = 0; i < SZ_PLATEAU; ++i) {
    for (int j = 0; j < SZ_PLATEAU; ++j) {
      partie->plateau.cases[i][j].couleur = Vide;
      partie->plateau.cases[i][j].forme = Vide;
    }
  }
}
void copie_plateau(Plateau *orig, Plateau *dest) {
  for (int i = 0; i < SZ_PLATEAU; ++i) {
    for (int j = 0; j < SZ_PLATEAU; ++j) {
      dest->cases[i][j] = orig->cases[i][j];
    }
  }
}

void init_pioche(Partie *partie) {
  // printf("entre dans l'initialisation de la pioche\n");
  partie->pioche.nombre_de_pions = 3 * (NUM_COULEUR - 1) * NUM_FORME;
  int idx = 0;
  for (int i = 0; i < 3; ++i) {
    for (int c = 1; c < NUM_COULEUR; ++c) {
      for (int f = 0; f < NUM_FORME; ++f) {
        partie->pioche.pions_pioche[idx].couleur = c;
        partie->pioche.pions_pioche[idx].forme = f;
        ++idx;
      }
    }
  }
  // printf("aaa\n");
  // partie->pioche.nombre_de_pions = 15;
}

Case pioche_piece(Partie *partie) {
  int random;
  Case ret;
  if (partie->pioche.nombre_de_pions == 0) {
    ret.couleur = Vide;
    ret.forme = Rond;
    return ret;
  }
  if (partie->pioche.nombre_de_pions == 1) {
    ret = partie->pioche.pions_pioche[0];
    --partie->pioche.nombre_de_pions;
    return ret;
  }

  // printf("entre dans l'initialisation des mains\n");
  random = rand() % partie->pioche.nombre_de_pions;
  ret = partie->pioche.pions_pioche[random];
  --partie->pioche.nombre_de_pions;
  partie->pioche.pions_pioche[random] =
      partie->pioche.pions_pioche[partie->pioche.nombre_de_pions];
  partie->pioche.pions_pioche[partie->pioche.nombre_de_pions].couleur = Vide;
  return ret;
}

void remet_pioche_piece(Partie *partie, Case piece) {
  if (piece.couleur == Vide)
    return;
  partie->pioche.pions_pioche[partie->pioche.nombre_de_pions] = piece;
  ++partie->pioche.nombre_de_pions;
}

// fonction qui genere un nombre entier aléatoire entre 2 nombres

void init_main_jeu(Partie *partie) {
  for (int i = 0; i < 6; ++i) {
    partie->joueur.jeu_nord.jeu[i] = pioche_piece(partie);
    partie->joueur.jeu_sud.jeu[i] = pioche_piece(partie);
    if (partie->nombre_joueurs >= 3) {
      partie->joueur.jeu_ouest.jeu[i] = pioche_piece(partie);
    }
    if (partie->nombre_joueurs > 3) {
      partie->joueur.jeu_est.jeu[i] = pioche_piece(partie);
    }
  }
}

void init_score(Partie *partie) {
  partie->joueur.score_sud = 0;
  partie->joueur.score_nord = 0;
  partie->joueur.score_ouest = 0;
  partie->joueur.score_est = 0;
}
void init_nombre_de_joueur(Partie *partie, int nb_joueur) {
  partie->nombre_joueurs = nb_joueur;
}

void partie_init(Partie *partie, int nb_joueur) {
  init_nombre_de_joueur(partie, nb_joueur);
  init_plateau(partie);
  init_pioche(partie);
  init_main_jeu(partie);
  init_score(partie);
  partie->joueur.position = premier_joueur(partie);
  partie->premier_pion = 1;
  partie->tour = 1;
  partie->nb_pieces_jouees = 0;
  for (int i = 0; i < 6; ++i) {
    partie->depotpioche[i].couleur = Vide;
  }
}

Case get_piece_main(int p, Partie *partie) {
  Jeu *cur_jeu = main_courante(partie);
  return cur_jeu->jeu[p];
}

void rempli_case_plateau(Plateau *plateau, Coord coord_plateau, Case piece) {
  plateau->cases[coord_plateau.y][coord_plateau.x] = piece;
}
void rempli_case(Partie *partie, Coord coord_plateau, Case piece) {
  partie->pos_jouees[partie->nb_pieces_jouees] = coord_plateau;
  ++partie->nb_pieces_jouees;
  rempli_case_plateau(&partie->plateau, coord_plateau, piece);
}

Case get_cases_coord_plateau(Plateau *plateau, int x,
                             int y) { // fonction permettant d'avoir la case du
                                      // plateau en ayant la case du plateau
  return plateau->cases[y][x];
}

// fonction changeant le joueur qui joue a la fin du tour et incrementant le
// nombre de tour
Position joueur_suivant(Partie *partie) {
  int joueur = partie->joueur.position;
  ++joueur;
  joueur = joueur % partie->nombre_joueurs;
  return joueur;
}

Dimension dimension_affichage_plateau(Partie *partie) {
  int i, j;
  Coord debuttab, fintab;
  debuttab.x = SZ_PLATEAU;
  debuttab.y = SZ_PLATEAU;
  fintab.x = -1;
  fintab.y = -1;
  int marge = 3;
  Dimension dimension_tab;
  for (i = 0; i < SZ_PLATEAU; i++) {
    for (j = 0; j < SZ_PLATEAU; j++) {
      if (get_cases_coord_plateau(&partie->plateau, j, i).couleur != Vide) {
        if ((j < debuttab.x)) {
          debuttab.x = j;
        }
        if ((j > fintab.x)) {
          fintab.x = j;
        }
        if ((i < debuttab.y)) {
          debuttab.y = i;
        }
        if ((i > fintab.y)) {
          fintab.y = i;
        }
      }
    }
  }
  // printf("AV %d %d %d %d w %d h %d\n", debuttab.x, debuttab.y, fintab.x,
  // fintab.y, fintab.x-debuttab.x,fintab.y-debuttab.y);

  if (debuttab.x == SZ_PLATEAU) {
    debuttab.x = SZ_PLATEAU / 2 - 10;
    debuttab.y = SZ_PLATEAU / 2 - 10;
    fintab.x = SZ_PLATEAU / 2 + 10;
    fintab.y = SZ_PLATEAU / 2 + 10;
  } else {
    debuttab.x -= marge;
    debuttab.y -= marge;
    fintab.x += marge;
    fintab.y += marge;
  }
  if (debuttab.x < 1)
    debuttab.x = 1;
  if (debuttab.y < 1)
    debuttab.y = 1;
  if (fintab.x >= SZ_PLATEAU - 1)
    fintab.x = SZ_PLATEAU - 2;
  if (fintab.y >= SZ_PLATEAU - 1)
    fintab.y = SZ_PLATEAU - 2;
  dimension_tab.nb_colonnes = ((fintab.x - debuttab.x) > (fintab.y - debuttab.y)
                                   ? (fintab.x - debuttab.x)
                                   : (fintab.y - debuttab.y));
  dimension_tab.nb_rangees = dimension_tab.nb_colonnes;
  debuttab.x = (debuttab.x + fintab.x) / 2 - dimension_tab.nb_colonnes / 2;
  debuttab.y = (debuttab.y + fintab.y) / 2 - dimension_tab.nb_rangees / 2;
  if (debuttab.x < 0)
    debuttab.x = 0;
  if (debuttab.y < 0)
    debuttab.y = 0;

  dimension_tab.a.x = debuttab.x;
  dimension_tab.a.y = debuttab.y;
  // printf("AP %d %d %d %d\n", debuttab.x, debuttab.y, fintab.x, fintab.y);
  partie->plateau.dimension_plateau_jeu = dimension_tab;
  // printf("AP %d %d %d %d w %d h %d \n", debuttab.x, debuttab.y, fintab.x,
  // fintab.y, fintab.x-debuttab.x,fintab.y-debuttab.y);

  return dimension_tab;
}

int calcul_score(Plateau *plateau, int nb_pieces_jouees, Coord *pos_jouees,
                 int tour) {
  char compte[SZ_PLATEAU][SZ_PLATEAU];
  if ((tour == 1) && (nb_pieces_jouees == 1)) {
    return 1;
  } else {
    for (int i = 0; i < SZ_PLATEAU; ++i)
      for (int j = 0; j < SZ_PLATEAU; ++j)
        compte[i][j] = 0;
    int cnt = 0;

    for (int i = 0; i < nb_pieces_jouees; ++i) {
      int n = 0;
      int x = pos_jouees[i].x;
      int y = pos_jouees[i].y;
      int cnt_ligne = 0;
      while (get_cases_coord_plateau(plateau, x + n, y).couleur != Vide) {
        if (compte[y][x + n] == 0) {
          ++cnt_ligne;
          compte[y][x + n] = 1;
        }
        ++n;
      }
      n = 0;
      while (get_cases_coord_plateau(plateau, x - n, y).couleur != Vide) {
        if (compte[y][x - n] == 0) {
          ++cnt_ligne;
          compte[y][x - n] = 1;
        }
        ++n;
        if (cnt_ligne == 6) {
          cnt = cnt + 6;
        }
      }
      if (cnt_ligne > 1) {
        cnt += cnt_ligne;
      }
    }

    for (int i = 0; i < SZ_PLATEAU; ++i)
      for (int j = 0; j < SZ_PLATEAU; ++j)
        compte[i][j] = 0;

    for (int i = 0; i < nb_pieces_jouees; ++i) {
      int n = 0;
      int x = pos_jouees[i].x;
      int y = pos_jouees[i].y;
      int cnt_ligne = 0;
      while (get_cases_coord_plateau(plateau, x, y + n).couleur != Vide) {
        if (compte[y + n][x] == 0) {
          ++cnt_ligne;
          compte[y + n][x] = 1;
        }
        ++n;
      }
      n = 0;
      while (get_cases_coord_plateau(plateau, x, y - n).couleur != Vide) {
        if (compte[y - n][x] == 0) {
          ++cnt_ligne;
          compte[y - n][x] = 1;
        }
        ++n;
        if (cnt_ligne == 6) {
          cnt = cnt + 6;
        }
      }
      if (cnt_ligne > 1) {
        cnt += cnt_ligne;
      }
    }
    return cnt;
  }
}

Case get_cases(Plateau *plateau, int x,
               int y) { // fonction permettant d'avoir la case du plateau en
                        // ayant la case de la fenetre
  return plateau->cases[plateau->dimension_plateau_jeu.a.y + y]
                       [plateau->dimension_plateau_jeu.a.x + x];
}

Coord get_coord_plateau(
    Plateau *plateau, int x,
    int y) { // fonction permettant d'obtenir les coordonnees d'une case du
             // plateau en ayant les coordonnees du gui

  Coord ret = {plateau->dimension_plateau_jeu.a.x + x,
               plateau->dimension_plateau_jeu.a.y + y};

  return ret;
}

void set_cases(
    Plateau *plateau, int x, int y,
    Case piece) { // fonction permettant de rmplir une case avec piece
  plateau->cases[plateau->dimension_plateau_jeu.a.y + y]
                [plateau->dimension_plateau_jeu.a.x + x] = piece;
}

void partie_fin_tour(
    Partie *partie,
    int piece_dispo[6]) { // fonction appelant les differentes fonction
                          // necessaire a la fin du tour (calcul du score...)
  Jeu *cur_jeu = main_courante(partie);
  for (int i = 0; i < 6; ++i) {
    if (piece_dispo[i] == 0) {
      cur_jeu->jeu[i] = pioche_piece(partie);
    }
  }
  for (int i = 0; i < 6; ++i) {
    piece_dispo[i] = 1;
  }
  for (int i = 0; i < 6; ++i) {
    if (partie->depotpioche[i].couleur != Vide) {
      remet_pioche_piece(partie, partie->depotpioche[i]);
    }
    partie->depotpioche[i].couleur = Vide;
  }
  //printf("Nombre de pions dans la pioche %d\n", partie->pioche.nombre_de_pions);
  partie->cur_pioche = 0;

  int score = calcul_score(&partie->plateau, partie->nb_pieces_jouees,
                           partie->pos_jouees, partie->tour);
  if (partie_finie(partie)) {
    score += 6;
  }
  if (partie->joueur.position == Sud) {
    partie->joueur.score_sud += score;
  }
  if (partie->joueur.position == Nord) {
    partie->joueur.score_nord += score;
  }
  if (partie->joueur.position == Ouest) {
    partie->joueur.score_ouest += score;
  }
  if (partie->joueur.position == Est) {
    partie->joueur.score_est += score;
  }
  // printf("Score: %d\n", calcul_score(partie));
  partie->joueur.position = joueur_suivant(partie);
  partie->nb_pieces_jouees = 0;
  ++partie->tour;
}

Jeu *main_courante(Partie *partie) {
  switch (partie->joueur.position) {
  case Sud:
    return &partie->joueur.jeu_sud;
    break;
  case Nord:
    return &partie->joueur.jeu_nord;
    break;
  case Ouest:
    return &partie->joueur.jeu_ouest;
    break;
  case Est:
    return &partie->joueur.jeu_est;
    break;
  default:
    return NULL;
  }
}

int partie_finie(Partie *partie) {
  int reste_des_pieces = 0;
  Jeu *cur_jeu = main_courante(partie);
  if (partie->pioche.nombre_de_pions == 0) {
    for (int i = 0; i < 6; ++i) {
      if (cur_jeu->jeu[i].couleur != Vide) {
        reste_des_pieces = 1;
        break;
      }
    }
    if (!reste_des_pieces) {
      return 1;
    }
  }
  return 0;
}